#!/usr/bin/env python3
"""Focused verification for Google Search Console meta tag in raw homepage HTML."""

import json
import re
import sys
import urllib.request
from datetime import datetime, timezone


URL = "https://book-ride-now-10.preview.emergentagent.com/"
EXPECTED_TAG = '<meta name="google-site-verification" content="y7goxoWrbipq7CWXRN4Dd4IvKfzuvjcfBYxlO67UN5w" />'
EXPECTED_NAME = "google-site-verification"
EXPECTED_CONTENT = "y7goxoWrbipq7CWXRN4Dd4IvKfzuvjcfBYxlO67UN5w"


def main():
    req = urllib.request.Request(
        URL,
        headers={
            "User-Agent": "Mozilla/5.0 (compatible; GSCMetaVerificationTest/1.0)",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
    )
    with urllib.request.urlopen(req, timeout=30) as response:
        status = response.status
        content_type = response.headers.get("content-type", "")
        raw = response.read().decode("utf-8", errors="replace")

    lower = raw.lower()
    head_start = lower.find("<head")
    head_open_end = lower.find(">", head_start) if head_start != -1 else -1
    head_end = lower.find("</head>")
    body_start = lower.find("<body")
    head_html = raw[head_open_end + 1 : head_end] if head_open_end != -1 and head_end != -1 else ""
    body_html = raw[body_start:] if body_start != -1 else ""

    exact_tag_count = raw.count(EXPECTED_TAG)
    exact_tag_in_head = EXPECTED_TAG in head_html
    exact_tag_in_body = EXPECTED_TAG in body_html
    tag_before_head_close = raw.find(EXPECTED_TAG) != -1 and head_end != -1 and raw.find(EXPECTED_TAG) < head_end

    meta_matches = re.findall(
        r'<meta\s+[^>]*name=["\']google-site-verification["\'][^>]*>',
        raw,
        flags=re.IGNORECASE,
    )
    exact_attr_match = re.search(
        r'<meta\s+name="google-site-verification"\s+content="y7goxoWrbipq7CWXRN4Dd4IvKfzuvjcfBYxlO67UN5w"\s*/>',
        raw,
    )
    case_sensitive_name_content_present = (
        f'name="{EXPECTED_NAME}"' in raw and f'content="{EXPECTED_CONTENT}"' in raw
    )

    checks = {
        "http_status_200": status == 200,
        "content_type_html": "text/html" in content_type.lower(),
        "head_element_found": head_start != -1 and head_end != -1 and head_start < head_end,
        "body_after_head": body_start == -1 or (head_end != -1 and head_end < body_start),
        "exact_tag_present_once_in_raw_html": exact_tag_count == 1,
        "exact_tag_inside_head": exact_tag_in_head,
        "exact_tag_before_head_close": tag_before_head_close,
        "exact_tag_not_inside_body": not exact_tag_in_body,
        "case_sensitive_name_and_content_exact": case_sensitive_name_content_present and exact_attr_match is not None,
    }
    result = {
        "url": URL,
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "status": status,
        "content_type": content_type,
        "expected_tag": EXPECTED_TAG,
        "exact_tag_count": exact_tag_count,
        "head_start_index": head_start,
        "head_end_index": head_end,
        "body_start_index": body_start,
        "matching_google_site_verification_meta_tags": meta_matches,
        "checks": checks,
        "passed": all(checks.values()),
    }
    print(json.dumps(result, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())