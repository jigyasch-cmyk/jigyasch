# AvSGo Updated Home Flow

- Customer can tap the customer area above Book Now to open Service Available / Pickup PIN.
- Book Now also opens the same customer service flow.
- First visit: Pickup PIN -> Service Available -> Name + Mobile -> Register & Save Customer.
- Customer Pickup PIN and profile are saved locally once and reused on next visit.
- Driver card opens Driver Registration / Panel flow.
- Manager card opens Manager Login / Panel flow.
- Tapping the AvSGo word/logo 5 times quickly opens the hidden Admin Login.
- Driver Pickup PIN is not required for dispatch; approved active online drivers can receive nearby requests.
