# AvSGo Full Setup — 2026-09-29

## Landing / Front
- Local hero asset: `frontend/public/avsgo-hero.jpg`
- No remote Unsplash hero dependency.
- AvSGo header includes menu and notification visual controls.
- AvSGo logo retains hidden Admin access: 5 taps -> `/admin/login`.
- Book Now / customer surface opens first-visit Pickup PIN flow.
- Saved customer + saved Pickup PIN go directly to Customer Panel on later visits.

## Customer Panel
- First visit: Pickup PIN -> service availability -> Name + Mobile -> save.
- Next visit: saved customer -> device GPS pickup.
- Drop places are common enabled AvSGo places; no Drop PIN restriction.
- Road distance uses backend OSRM route calculation.
- Vehicle types: E-Rickshaw, Tata Ace, Tempo, Tractor.
- Fare comes from admin-configured vehicle fare settings.
- Booking broadcasts to eligible nearby approved/active/online drivers.

## Driver Panel
- Driver registration does not require a Pickup PIN.
- Driver has no dispatch-area PIN restriction.
- Vehicle type, plate, capacity, vehicle photo and RC photo can be submitted for approval.
- Approved + active + online drivers can receive nearby bookings.
- Booking request shows a 30-second countdown.
- First valid Accept is protected by backend atomic locking.
- Reject/timeout causes backend redispatch according to the configured limits.
- GPS sharing, customer pickup route and live trip map are present.
- Customer payment can be marked received.
- Driver commission/UPI/receipt workflow is present.

## Manager Panel
- Manager login and assigned Pickup PIN access.
- Permission-based customer, driver, vehicle, drop-place, booking, payment and report controls.
- Drop-place management supports unlimited places with no Drop PIN restriction.
- Manager commission percentage and payout history are present.
- Deactivated/resigned managers lose access while historical records remain.

## Admin Panel
- Hidden entry via five AvSGo taps.
- Admin registration/login.
- Pickup PIN service-area enable/disable.
- Unlimited drop-place management.
- Vehicle/fare settings.
- Driver and vehicle approval.
- Customer/manager/booking/payment/report controls.
- Driver commission settlement and manager payout/receipt flows.

## Important verification limitation
This ZIP has been source-inspected and the backend compiles successfully. A full production integration test (MongoDB + deployed backend + browser GPS/WebSocket + production frontend build) was not completed in this execution environment because the ZIP does not contain frontend dependencies and the test configuration requires pytest-xdist plus live service/environment access. Therefore this package is not represented as 100% production-tested.
