# AvSGo Android Build

## Backend
The mobile app is configured to use:
https://avsgo.onrender.com

The frontend still supports `REACT_APP_BACKEND_URL` for overrides.

## Package
`com.avsgo.app`

## Structure
The existing AvSGo frontend/backend structure is preserved. No Customer/Driver/Manager/Admin flow was intentionally redesigned.

## Build
From `frontend/`:
1. `npm install`
2. `npm run build`
3. `npx cap add android`
4. `npx cap sync android`
5. `cd android && ./gradlew assembleDebug` for APK
6. `cd android && ./gradlew bundleRelease` for AAB

The included GitHub Actions workflow can perform these steps on a GitHub runner.

## Play Store signing
A Play Store release AAB must be signed with an upload/release key. Do not put a keystore password or private key in source code. Configure signing secrets only in the build environment.
