@echo off
setlocal
cd /d "%~dp0"

echo =====================================
echo AvSGo - Windows Setup
echo =====================================

where python >nul 2>nul || (echo Python is not installed. Install Python 3.11/3.12 and rerun.&pause&exit /b 1)
where node >nul 2>nul || (echo Node.js is not installed. Install Node.js 20 LTS and rerun.&pause&exit /b 1)

if not exist .venv python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r backend\requirements-minimal.txt

cd frontend
if not exist node_modules (
  where yarn >nul 2>nul && yarn install --frozen-lockfile || npm install
)
if not exist .env.local copy ..\.env.local.example .env.local
cd ..

echo.
echo Setup packages installed.
echo IMPORTANT: MongoDB must be running locally on mongodb://localhost:27017
pause
