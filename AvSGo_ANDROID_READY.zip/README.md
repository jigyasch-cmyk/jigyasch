# AvSGo

**AvSGo** — Local vehicle booking & goods transport in Assam. Customers book E-rickshaw, Tata Ace, Tempo or Tractor from admin-verified owners and drivers.

- Customer panel: no login, `/customer`
- Driver / Vehicle Owner panel: mobile + password, `/driver`
- Admin panel: `/admin`

Preview: https://avsgo.onrender.com/docs
Production: https://avsgo.onrender.com
