@echo off
setlocal
cd /d "%~dp0"
start "AvSGo Backend" cmd /k "call .venv\Scripts\activate.bat && cd backend && python -m uvicorn server:app --host 0.0.0.0 --port 8000 --reload"
timeout /t 3 >nul
start "AvSGo Frontend" cmd /k "cd frontend && yarn start"
echo AvSGo should open at http://localhost:3000
