# AvSGo — Final implementation update (retry)

## Updated in this retry
- Fixed booking fare calculation runtime issue: gross_fare/discount values are now calculated before persistence.
- Booking and auto-assignment now resolve Manager/Pickup-PIN-specific fare settings and Admin-only Manager discount (default 0%).
- Drop-place coordinates now use the stored latitude/longitude fields correctly.
- Driver GPS posting was tightened to approximately every 5 seconds for live movement, with the active-trip watcher reacting to booking status changes.
- Added Admin API to view a Manager's UPI/QR payment settings and commission payable/paid/remaining summary.
- Added Admin UI for Admin UPI ID + QR upload/replace.
- Added Manager UI for Manager UPI ID + QR upload/replace so Admin can use it for payout.
- Added Admin Manager edit UI for Manager-wise vehicle Base Fare + Per KM and Admin-only Manager-wise Discount.
- Driver commission payment now reads the latest saved Admin UPI/QR settings.
- Realtime driver GPS -> WebSocket booking event -> customer live map remains enabled, with polling fallback.

## Verification
- Python compilation: PASS (`backend/server.py` and backend Python files parse successfully).
- Full pytest suite: BLOCKED because repository requires `pytest-xdist` and network/package installation is unavailable in this environment.
- Backend runtime import: BLOCKED because runtime dependencies (including `motor`) are not installed in this environment.
- Frontend production build: BLOCKED because frontend `node_modules` are not included and dependencies cannot be installed without network access.
- Real two-device GPS/WebSocket/MongoDB production test: NOT executable in this environment.

## Important
This package has been updated substantially, including the critical Live Movement path, but it must not be described as 100% production-tested until the environment-dependent checks above pass on the actual deployment with MongoDB, installed dependencies, and two real browser/device sessions.
