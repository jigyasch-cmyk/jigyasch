# AvSGo FINAL integration notes

## Core rules
- Pickup = Admin-enabled Pickup PIN service area.
- Manager = assigned Pickup PIN(s) + Admin-controlled permissions.
- Drop = no Drop PIN restriction; unlimited common Drop Places.
- Driver eligibility = approved + active + online; no Pickup PIN restriction.
- First valid driver acceptance wins through backend atomic booking assignment.
- Admin = full control.
- Customer = saved profile + own bookings.

## Admin
- Hidden entry: five taps on AvSGo logo.
- First use: Registration + Save. Later use: Mobile + Password Login.
- Service Areas: add/edit/enable/disable Pickup PINs.
- Drop Places: add/edit/enable/disable unlimited places.
- Managers: add/login credentials, assign Pickup PINs, permissions, commission %, active/inactive, resign.
- Manager Payouts: record payment, receipt file reference, note and payment history.

## Manager
- Login: Manager ID + password.
- Access is blocked when inactive/resigned.
- Every protected manager API checks the configured permission.
- Manager Drop Places are added to the common table and are not restricted as destinations by Drop PIN.
- Manager commission = completed bookings' Admin commission total × Manager commission %.
- Manager payment history shows Admin payouts and receipt references.

## Customer
- First visit: Pickup PIN -> Service Available -> Name + Mobile -> Saved locally.
- Next visit: saved customer opens directly; saved Pickup PIN is restored.
- Current device GPS becomes pickup automatically when trip-detail flow starts.
- Drop is selected from enabled Admin/Manager common Drop Places.
- Road distance is calculated automatically by routing backend.

## Driver
- Driver registration is the only driver entry flow; separate driver login UI is disabled.
- Driver must be approved and active before operational APIs work.
- Driver can receive nearest-driver dispatch notifications regardless of Pickup PIN.
- 30-second accept/reject/timeout dispatch and atomic assignment are retained.
- Customer payment is marked complete by Driver after receiving payment.
- Driver commission payment can be submitted to Admin with transaction/receipt details.
