"""AvSGo Admin Vehicle Availability tests: PATCH /api/admin/vehicles/{id}/availability
covers hide from public, block bookings, restore, admin-only auth, persistence, and
regression that approve/reject doesn't clobber the field."""
import os
import uuid
import pytest
import requests

BASE_URL = (os.environ.get('REACT_APP_BACKEND_URL') or 'https://book-ride-now-10.preview.emergentagent.com').rstrip('/')
API = f"{BASE_URL}/api"

ADMIN = {'mobile': '9365306642', 'password': 'Jigyasch@98'}
DRIVER = {'mobile': '9000000001', 'password': 'Driver@123'}


@pytest.fixture(scope='module')
def tokens():
    a = requests.post(f"{API}/auth/admin/login", json=ADMIN, timeout=30)
    assert a.status_code == 200, a.text
    d = requests.post(f"{API}/auth/driver/login", json=DRIVER, timeout=30)
    assert d.status_code == 200, d.text
    return {'atok': a.json()['token'], 'dtok': d.json()['token'],
            'did': d.json()['driver']['id']}


@pytest.fixture(scope='module')
def approved_vehicle(tokens):
    """Add a fresh vehicle, admin approves it, returns id + type."""
    plate = f"AS03AV{uuid.uuid4().hex[:4].upper()}"
    r = requests.post(f"{API}/driver/vehicles",
                      json={'vehicle_type': 'E-Rickshaw', 'plate_no': plate, 'capacity': '200kg'},
                      headers={'Authorization': f'Bearer {tokens["dtok"]}'}, timeout=30)
    assert r.status_code == 200, r.text
    v = r.json()
    # New vehicles must default to available:true (feature spec)
    assert v.get('available') is True, f"add_vehicle should default available=true, got {v}"
    vid = v['id']

    ap = requests.patch(f"{API}/admin/vehicles/{vid}", json={'action': 'approve'},
                        headers={'Authorization': f'Bearer {tokens["atok"]}'}, timeout=30)
    assert ap.status_code == 200
    return {'id': vid, 'type': 'E-Rickshaw', 'plate': plate}


class TestBackfillAndListing:
    def test_admin_vehicles_have_available_field(self, tokens):
        r = requests.get(f"{API}/admin/vehicles",
                         headers={'Authorization': f'Bearer {tokens["atok"]}'}, timeout=30)
        assert r.status_code == 200
        vehicles = r.json()
        assert isinstance(vehicles, list) and len(vehicles) > 0
        missing = [v['id'] for v in vehicles if 'available' not in v]
        assert not missing, f"vehicles missing 'available' after backfill: {missing[:5]}"
        # Approved existing ones should be available=true post-backfill
        approved = [v for v in vehicles if v['status'] == 'approved']
        assert all(v['available'] is True for v in approved), \
            "backfill should set available=true on all approved vehicles"


class TestAvailabilityAuth:
    def test_no_token_forbidden(self, approved_vehicle):
        r = requests.patch(f"{API}/admin/vehicles/{approved_vehicle['id']}/availability",
                           json={'available': False}, timeout=30)
        assert r.status_code in (401, 403)

    def test_driver_token_forbidden(self, tokens, approved_vehicle):
        r = requests.patch(f"{API}/admin/vehicles/{approved_vehicle['id']}/availability",
                           json={'available': False},
                           headers={'Authorization': f'Bearer {tokens["dtok"]}'}, timeout=30)
        assert r.status_code in (401, 403)


class TestAvailabilityToggle:
    def test_toggle_off_hides_from_public_and_blocks_booking(self, tokens, approved_vehicle):
        vid = approved_vehicle['id']
        vtype = approved_vehicle['type']

        # Ensure it's visible first
        pub = requests.get(f"{API}/public/vehicles", timeout=30).json()
        assert any(v['id'] == vid for v in pub), "vehicle should be visible before toggle"

        # Mark not available
        r = requests.patch(f"{API}/admin/vehicles/{vid}/availability",
                          json={'available': False},
                          headers={'Authorization': f'Bearer {tokens["atok"]}'}, timeout=30)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body == {'id': vid, 'available': False}

        # Public list must NOT contain it
        pub2 = requests.get(f"{API}/public/vehicles", timeout=30).json()
        assert not any(v['id'] == vid for v in pub2), "hidden vehicle appeared in /public/vehicles"

        # Even when filtering by vehicle_type
        pub3 = requests.get(f"{API}/public/vehicles", params={'vehicle_type': vtype}, timeout=30).json()
        assert not any(v['id'] == vid for v in pub3)

        # POST booking must fail with 404 'Vehicle not available'
        br = requests.post(f"{API}/customer/bookings", json={
            'vehicle_id': vid, 'customer_name': 'TEST_A', 'customer_mobile': '9111100022',
            'pickup': 'P', 'drop_location': 'D', 'distance_km': 4,
        }, timeout=30)
        assert br.status_code == 404
        assert br.json().get('detail') == 'Vehicle not available'

        # Persistence across requests: admin GET should show available:false
        av = requests.get(f"{API}/admin/vehicles",
                          headers={'Authorization': f'Bearer {tokens["atok"]}'}, timeout=30).json()
        me = next((v for v in av if v['id'] == vid), None)
        assert me and me['available'] is False

    def test_toggle_on_restores_and_allows_booking(self, tokens, approved_vehicle):
        vid = approved_vehicle['id']
        r = requests.patch(f"{API}/admin/vehicles/{vid}/availability",
                          json={'available': True},
                          headers={'Authorization': f'Bearer {tokens["atok"]}'}, timeout=30)
        assert r.status_code == 200
        assert r.json() == {'id': vid, 'available': True}

        pub = requests.get(f"{API}/public/vehicles", timeout=30).json()
        assert any(v['id'] == vid for v in pub), "vehicle should reappear in /public/vehicles"

        br = requests.post(f"{API}/customer/bookings", json={
            'vehicle_id': vid, 'customer_name': 'TEST_B', 'customer_mobile': '9111100033',
            'pickup': 'P', 'drop_location': 'D', 'distance_km': 3,
        }, timeout=30)
        assert br.status_code == 200, br.text
        assert br.json()['status'] == 'requested'


class TestApproveDoesNotClobber:
    def test_approve_preserves_availability(self, tokens):
        """Add a new vehicle, mark it approved, then set unavailable,
        re-approve (idempotent 'approve') and confirm available field preserved."""
        plate = f"AS04PP{uuid.uuid4().hex[:4].upper()}"
        r = requests.post(f"{API}/driver/vehicles",
                          json={'vehicle_type': 'Tata Ace', 'plate_no': plate, 'capacity': '750kg'},
                          headers={'Authorization': f'Bearer {tokens["dtok"]}'}, timeout=30)
        assert r.status_code == 200
        vid = r.json()['id']
        # approve
        requests.patch(f"{API}/admin/vehicles/{vid}", json={'action': 'approve'},
                       headers={'Authorization': f'Bearer {tokens["atok"]}'}, timeout=30)
        # set unavailable
        requests.patch(f"{API}/admin/vehicles/{vid}/availability", json={'available': False},
                       headers={'Authorization': f'Bearer {tokens["atok"]}'}, timeout=30)
        # re-approve
        requests.patch(f"{API}/admin/vehicles/{vid}", json={'action': 'approve'},
                       headers={'Authorization': f'Bearer {tokens["atok"]}'}, timeout=30)

        av = requests.get(f"{API}/admin/vehicles",
                          headers={'Authorization': f'Bearer {tokens["atok"]}'}, timeout=30).json()
        me = next((v for v in av if v['id'] == vid), None)
        assert me and me['available'] is False, f"approve should not clobber availability: {me}"


class TestRegressionShapes:
    def test_admin_stats_shape(self, tokens):
        r = requests.get(f"{API}/admin/stats",
                         headers={'Authorization': f'Bearer {tokens["atok"]}'}, timeout=30)
        assert r.status_code == 200
        for k in ('drivers', 'pending_vehicles', 'completed_trips', 'revenue', 'commission_earned', 'upi'):
            assert k in r.json()

    def test_driver_commission_shape(self, tokens):
        r = requests.get(f"{API}/driver/commission",
                         headers={'Authorization': f'Bearer {tokens["dtok"]}'}, timeout=30)
        assert r.status_code == 200
        for k in ('commission_owed', 'total_earnings', 'trips', 'upi'):
            assert k in r.json()

    def test_404_unknown_vehicle_availability(self, tokens):
        r = requests.patch(f"{API}/admin/vehicles/nonexistent-id/availability",
                          json={'available': False},
                          headers={'Authorization': f'Bearer {tokens["atok"]}'}, timeout=30)
        assert r.status_code == 404
