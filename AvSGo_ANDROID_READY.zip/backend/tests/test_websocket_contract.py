from pathlib import Path


def test_websocket_contract_present():
    src = Path(__file__).resolve().parents[1] / "server.py"
    text = src.read_text()
    assert "@app.websocket('/api/ws/driver')" in text
    assert "@app.websocket('/api/ws/customer')" in text
    assert "class BookingSocketManager" in text
    assert "await ws_manager.booking_event" in text
    assert "await ws_manager.driver_event" in text
    assert "driver_location" in text
    assert "customer_location" in text
