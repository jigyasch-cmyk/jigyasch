"""AvSGo in-app notification bell tests (iteration 6).

Covers:
  * GET /api/inapp/notifications auth & role-scoped list
  * POST /api/inapp/notifications/mark-read (all / by id)
  * Driver <-> driver isolation
  * Notifications created by booking-create, vehicle-approve, admin/notify-driver
  * Existing endpoints unchanged (/api/driver/notifications, /api/push/*).
"""
import os
import uuid
import time
import pytest
import requests

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL').rstrip('/')
API = f"{BASE_URL}/api"

ADMIN = {'mobile': '9365306642', 'password': 'Jigyasch@98'}
DRIVER1 = {'mobile': '9000000001', 'password': 'Driver@123'}


def _login_admin():
    r = requests.post(f"{API}/auth/admin/login", json=ADMIN, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()['token']


def _login_driver(mobile=DRIVER1['mobile'], password=DRIVER1['password']):
    r = requests.post(f"{API}/auth/driver/login", json={'mobile': mobile, 'password': password}, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()['token'], r.json()['driver']['id']


def _register_driver():
    mobile = '9' + str(uuid.uuid4().int)[:9]
    body = {'name': f'TEST_{mobile}', 'mobile': mobile, 'password': 'Driver@123'}
    r = requests.post(f"{API}/auth/driver/register", json=body, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()['token'], r.json()['driver']['id'], mobile


def _hdr(tok):
    return {'Authorization': f'Bearer {tok}'}


def _mark_all_read(tok):
    return requests.post(f"{API}/inapp/notifications/mark-read", json={}, headers=_hdr(tok), timeout=30)


class TestAuthAndShape:
    def test_unauth_returns_401_or_403(self):
        r = requests.get(f"{API}/inapp/notifications", timeout=30)
        assert r.status_code in (401, 403), r.status_code

    def test_admin_initial_shape(self):
        tok = _login_admin()
        # Clean slate for admin so subsequent tests are deterministic
        _mark_all_read(tok)
        r = requests.get(f"{API}/inapp/notifications", headers=_hdr(tok), timeout=30)
        assert r.status_code == 200
        data = r.json()
        assert 'items' in data and isinstance(data['items'], list)
        assert 'unread' in data and isinstance(data['unread'], int)
        assert data['unread'] == 0


class TestBookingCreatesNotifications:
    @pytest.fixture(scope='class')
    def setup(self):
        atok = _login_admin()
        dtok, did = _login_driver()
        # Ensure clean unread for both
        _mark_all_read(atok)
        _mark_all_read(dtok)

        # Add and approve a vehicle
        plate = f"AS02BE{uuid.uuid4().hex[:4].upper()}"
        add = requests.post(f"{API}/driver/vehicles",
                            json={'vehicle_type': 'E-Rickshaw', 'plate_no': plate, 'capacity': '200kg'},
                            headers=_hdr(dtok), timeout=30)
        assert add.status_code == 200, add.text
        vid = add.json()['id']
        # approving triggers driver inapp notification too, so mark read after
        ap = requests.patch(f"{API}/admin/vehicles/{vid}", json={'action': 'approve'},
                            headers=_hdr(atok), timeout=30)
        assert ap.status_code == 200
        return {'atok': atok, 'dtok': dtok, 'did': did, 'vid': vid}

    def test_vehicle_approval_notifies_driver(self, setup):
        # There should be at least one unread notif with "approved" in title for driver
        r = requests.get(f"{API}/inapp/notifications", headers=_hdr(setup['dtok']), timeout=30)
        assert r.status_code == 200
        data = r.json()
        assert data['unread'] >= 1
        assert any('approved' in (i.get('title') or '').lower() for i in data['items'])
        # clean for booking test
        _mark_all_read(setup['dtok'])
        _mark_all_read(setup['atok'])

    def test_booking_creates_admin_and_driver_notifications(self, setup):
        body = {
            'vehicle_id': setup['vid'],
            'customer_name': 'TEST_Bell',
            'customer_mobile': '9111100022',
            'pickup': 'A', 'drop_location': 'B', 'distance_km': 4,
        }
        cr = requests.post(f"{API}/customer/bookings", json=body, timeout=30)
        assert cr.status_code == 200, cr.text

        # Admin
        ar = requests.get(f"{API}/inapp/notifications", headers=_hdr(setup['atok']), timeout=30)
        assert ar.status_code == 200
        adata = ar.json()
        assert adata['unread'] >= 1
        assert any(i.get('title') == 'New booking created' for i in adata['items']), adata['items'][:3]

        # Driver
        dr = requests.get(f"{API}/inapp/notifications", headers=_hdr(setup['dtok']), timeout=30)
        assert dr.status_code == 200
        ddata = dr.json()
        assert ddata['unread'] >= 1
        assert any(i.get('title') == 'New booking request' for i in ddata['items']), ddata['items'][:3]


class TestMarkRead:
    def test_mark_all_and_mark_by_id(self):
        atok = _login_admin()
        dtok, did = _login_driver()
        # produce a fresh notification for admin by adding a vehicle
        plate = f"AS02CF{uuid.uuid4().hex[:4].upper()}"
        add = requests.post(f"{API}/driver/vehicles",
                            json={'vehicle_type': 'Tempo', 'plate_no': plate, 'capacity': '500kg'},
                            headers=_hdr(dtok), timeout=30)
        assert add.status_code == 200

        r = requests.get(f"{API}/inapp/notifications", headers=_hdr(atok), timeout=30)
        assert r.status_code == 200
        data = r.json()
        assert data['unread'] >= 1
        prev_unread = data['unread']

        # mark by id -> unread decreases by 1
        one_id = data['items'][0]['id']
        m = requests.post(f"{API}/inapp/notifications/mark-read", json={'id': one_id},
                          headers=_hdr(atok), timeout=30)
        assert m.status_code == 200 and m.json().get('ok') is True
        r2 = requests.get(f"{API}/inapp/notifications", headers=_hdr(atok), timeout=30)
        assert r2.json()['unread'] == prev_unread - 1

        # mark all -> unread == 0, items still present
        m2 = _mark_all_read(atok)
        assert m2.status_code == 200
        r3 = requests.get(f"{API}/inapp/notifications", headers=_hdr(atok), timeout=30)
        d3 = r3.json()
        assert d3['unread'] == 0
        assert len(d3['items']) >= 1


class TestDriverIsolation:
    def test_second_driver_does_not_see_or_affect_first(self):
        atok = _login_admin()
        dtok1, did1 = _login_driver()
        dtok2, did2, mobile2 = _register_driver()

        # Ensure driver1 has at least one unread by admin notify-driver
        n = requests.post(f"{API}/admin/notify-driver",
                         json={'driver_id': did1, 'message': 'TEST_isolate1'},
                         headers=_hdr(atok), timeout=30)
        assert n.status_code == 200, n.text

        r1 = requests.get(f"{API}/inapp/notifications", headers=_hdr(dtok1), timeout=30)
        assert r1.status_code == 200
        d1 = r1.json()
        assert d1['unread'] >= 1
        assert any('TEST_isolate1' in (i.get('body') or '') for i in d1['items'])
        d1_unread_before = d1['unread']

        # Driver 2 should NOT see driver 1's notification
        r2 = requests.get(f"{API}/inapp/notifications", headers=_hdr(dtok2), timeout=30)
        assert r2.status_code == 200
        d2 = r2.json()
        assert not any('TEST_isolate1' in (i.get('body') or '') for i in d2['items'])

        # Driver 2 mark-all-read must not affect driver 1
        _mark_all_read(dtok2)
        r1b = requests.get(f"{API}/inapp/notifications", headers=_hdr(dtok1), timeout=30)
        assert r1b.json()['unread'] == d1_unread_before

        # Admin should also not receive driver-scoped notifications in its bell (isolation)
        ar = requests.get(f"{API}/inapp/notifications", headers=_hdr(atok), timeout=30)
        assert ar.status_code == 200
        assert not any('TEST_isolate1' in (i.get('body') or '') for i in ar.json()['items'])


class TestExistingEndpointsUnchanged:
    def test_driver_notifications_still_works(self):
        atok = _login_admin()
        dtok, did = _login_driver()
        # push a commission notification
        n = requests.post(f"{API}/admin/notify-driver",
                         json={'driver_id': did, 'message': 'TEST_commission_reminder'},
                         headers=_hdr(atok), timeout=30)
        assert n.status_code == 200
        r = requests.get(f"{API}/driver/notifications", headers=_hdr(dtok), timeout=30)
        assert r.status_code == 200
        arr = r.json()
        assert isinstance(arr, list) and len(arr) >= 1
        # each item should have the expected legacy shape
        it = arr[0]
        for k in ('id', 'driver_id', 'message', 'amount', 'upi', 'created_at', 'read'):
            assert k in it

    def test_push_public_key_and_subscribe(self):
        r = requests.get(f"{API}/push/public-key", timeout=30)
        assert r.status_code == 200 and 'public_key' in r.json()

        body = {
            'subscriber_key': 'customer:9111100099',
            'subscription': {'endpoint': f'https://example.com/e-{uuid.uuid4()}',
                             'keys': {'p256dh': 'x', 'auth': 'y'}},
        }
        r2 = requests.post(f"{API}/push/subscribe", json=body, timeout=30)
        assert r2.status_code == 200 and r2.json() == {'ok': True}
