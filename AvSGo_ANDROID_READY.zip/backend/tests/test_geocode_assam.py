"""Backend tests for iter16: Assam-biased /api/geocode + regression checks."""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://book-ride-now-10.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"


# ------- Geocode Assam-bias tests -------
@pytest.mark.parametrize("q", ["Nalbari", "Beltola", "Kamakhya", "Rangia", "Barpeta"])
def test_geocode_returns_assam_local_results(q):
    r = requests.get(f"{API}/geocode", params={"q": q}, timeout=20)
    assert r.status_code == 200, r.text
    data = r.json()
    assert "results" in data
    results = data["results"]
    assert isinstance(results, list)
    assert len(results) >= 1, f"No results for {q}"
    # First results should include 'Assam' in display_name
    assam_hits = [x for x in results if "Assam" in (x.get("display_name") or "")]
    assert assam_hits, f"No Assam results for '{q}': {[x.get('display_name') for x in results]}"
    # schema
    first = results[0]
    assert "lat" in first and "lng" in first and "display_name" in first
    assert isinstance(first["lat"], float)
    assert isinstance(first["lng"], float)


def test_geocode_beltola_market_multi():
    r = requests.get(f"{API}/geocode", params={"q": "Beltola market"}, timeout=20)
    assert r.status_code == 200
    results = r.json()["results"]
    assert len(results) >= 1
    # At least one should be Assam-local
    assert any("Assam" in (x.get("display_name") or "") for x in results)


def test_geocode_limit_param():
    r = requests.get(f"{API}/geocode", params={"q": "Guwahati", "limit": 3}, timeout=20)
    assert r.status_code == 200
    results = r.json()["results"]
    assert len(results) <= 3


def test_geocode_default_limit_max_8():
    r = requests.get(f"{API}/geocode", params={"q": "Guwahati"}, timeout=20)
    assert r.status_code == 200
    results = r.json()["results"]
    assert len(results) <= 8


def test_geocode_limit_over_max_rejected():
    r = requests.get(f"{API}/geocode", params={"q": "Guwahati", "limit": 50}, timeout=20)
    assert r.status_code == 422  # pydantic validation


def test_geocode_short_query_rejected():
    r = requests.get(f"{API}/geocode", params={"q": "a"}, timeout=20)
    assert r.status_code == 422


# ------- Regression -------
def test_reverse_geocode_guwahati():
    r = requests.get(f"{API}/reverse-geocode", params={"lat": 26.1445, "lng": 91.7362}, timeout=20)
    assert r.status_code == 200
    d = r.json()
    assert "display_name" in d


def test_route_osrm_guwahati_dispur():
    r = requests.post(f"{API}/route", json={
        "pickup_lat": 26.1445, "pickup_lng": 91.7362,
        "drop_lat": 26.1433, "drop_lng": 91.7898,
        "vehicle_type": "E-Rickshaw",
    }, timeout=30)
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["distance_km"] > 0
    assert d.get("geometry") and len(d["geometry"]) > 1


def test_public_vehicles():
    r = requests.get(f"{API}/public/vehicles", timeout=15)
    assert r.status_code == 200
    assert isinstance(r.json(), list)


def test_fare_settings():
    r = requests.get(f"{API}/fare-settings", timeout=15)
    assert r.status_code == 200
    assert isinstance(r.json(), list)
    assert len(r.json()) > 0


def test_upi_settings():
    r = requests.get(f"{API}/upi", timeout=15)
    assert r.status_code == 200


def test_customer_booking_create_manual():
    # Get a vehicle
    v = requests.get(f"{API}/public/vehicles", timeout=15).json()
    if not v:
        pytest.skip("No vehicles seeded")
    payload = {
        "vehicle_id": v[0]["id"],
        "customer_name": "TEST_Geo",
        "customer_mobile": "9876500099",
        "pickup": "TEST Nalbari, Assam",
        "drop_location": "TEST Guwahati, Assam",
        "distance_km": 60.0,
        "pickup_lat": 26.4432, "pickup_lng": 91.4380,
    }
    r = requests.post(f"{API}/customer/bookings", json=payload, timeout=20)
    assert r.status_code in (200, 201), r.text
    b = r.json()
    assert b.get("id") and b.get("fare", 0) > 0
