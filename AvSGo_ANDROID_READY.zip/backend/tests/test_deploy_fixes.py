"""Regression tests for deployment-readiness fixes:
1) Admin creds moved to env vars.
2) /api/admin/drivers rewritten to single $group aggregation.
"""
import os
import time
import uuid
import pytest
import requests

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'https://book-ride-now-10.preview.emergentagent.com').rstrip('/')
API = f"{BASE_URL}/api"


@pytest.fixture(scope='module')
def admin_token():
    r = requests.post(f"{API}/auth/admin/login",
                      json={'mobile': '9365306642', 'password': 'Jigyasch@98'}, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()['token']


@pytest.fixture(scope='module')
def driver_ctx():
    dl = requests.post(f"{API}/auth/driver/login",
                       json={'mobile': '9000000001', 'password': 'Driver@123'}, timeout=30)
    assert dl.status_code == 200, dl.text
    d = dl.json()
    return {'token': d['token'], 'id': d['driver']['id']}


class TestAdminLoginEnv:
    def test_admin_login_ok(self, admin_token):
        assert isinstance(admin_token, str) and len(admin_token) > 20

    def test_admin_login_wrong_password(self):
        r = requests.post(f"{API}/auth/admin/login",
                          json={'mobile': '9365306642', 'password': 'wrongpass'}, timeout=30)
        assert r.status_code == 401

    def test_admin_login_wrong_mobile(self):
        r = requests.post(f"{API}/auth/admin/login",
                          json={'mobile': '9000000000', 'password': 'Jigyasch@98'}, timeout=30)
        assert r.status_code == 401


class TestAdminDriversShape:
    def test_endpoint_fast_and_shape(self, admin_token):
        t0 = time.time()
        r = requests.get(f"{API}/admin/drivers",
                         headers={'Authorization': f'Bearer {admin_token}'}, timeout=30)
        dt = time.time() - t0
        assert r.status_code == 200, r.text
        drivers = r.json()
        assert isinstance(drivers, list)
        assert dt < 10, f"took {dt:.2f}s (aggregation should be fast)"
        for d in drivers:
            assert 'id' in d
            assert 'commission_owed' in d
            assert 'completed_trips' in d
            assert isinstance(d['commission_owed'], (int, float))
            assert isinstance(d['completed_trips'], int)

    def test_no_auth_forbidden(self):
        r = requests.get(f"{API}/admin/drivers", timeout=30)
        assert r.status_code in (401, 403)

    def test_commission_math_matches_bookings(self, admin_token, driver_ctx):
        """Create a completed booking for the seeded driver, verify commission_owed & completed_trips."""
        # Snapshot before
        r0 = requests.get(f"{API}/admin/drivers",
                          headers={'Authorization': f'Bearer {admin_token}'}, timeout=30)
        assert r0.status_code == 200
        before = {d['id']: d for d in r0.json()}
        drv_before = before.get(driver_ctx['id'])
        assert drv_before is not None, "seeded driver not present in /admin/drivers"
        commission_before = float(drv_before['commission_owed'])
        trips_before = int(drv_before['completed_trips'])

        # add a vehicle
        plate = f"AS02ZZ{uuid.uuid4().hex[:4].upper()}"
        add = requests.post(f"{API}/driver/vehicles",
                            json={'vehicle_type': 'E-Rickshaw', 'plate_no': plate, 'capacity': '200kg'},
                            headers={'Authorization': f'Bearer {driver_ctx["token"]}'}, timeout=30)
        assert add.status_code == 200, add.text
        vid = add.json()['id']
        # approve
        ap = requests.patch(f"{API}/admin/vehicles/{vid}", json={'action': 'approve'},
                            headers={'Authorization': f'Bearer {admin_token}'}, timeout=30)
        assert ap.status_code == 200

        # Create booking + accept + complete
        cr = requests.post(f"{API}/customer/bookings", json={
            'vehicle_id': vid, 'customer_name': 'TEST_Commission', 'customer_mobile': '9333300033',
            'pickup': 'P', 'drop_location': 'D', 'distance_km': 7,
        }, timeout=30)
        assert cr.status_code == 200, cr.text
        bid = cr.json()['id']
        ac = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'accept'},
                            headers={'Authorization': f'Bearer {driver_ctx["token"]}'}, timeout=30)
        assert ac.status_code == 200
        cp = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'complete'},
                            headers={'Authorization': f'Bearer {driver_ctx["token"]}'}, timeout=30)
        assert cp.status_code == 200
        booking = cp.json()
        commission_of_this = float(booking.get('commission') or 0)
        assert commission_of_this > 0, f"commission not set on booking: {booking}"

        # After
        r1 = requests.get(f"{API}/admin/drivers",
                          headers={'Authorization': f'Bearer {admin_token}'}, timeout=30)
        assert r1.status_code == 200
        after = {d['id']: d for d in r1.json()}
        drv_after = after[driver_ctx['id']]
        assert int(drv_after['completed_trips']) == trips_before + 1
        # Commission owed grew by exactly commission_of_this
        delta = float(drv_after['commission_owed']) - commission_before
        assert abs(delta - commission_of_this) < 0.01, f"delta={delta} expected={commission_of_this}"

    def test_driver_with_no_completed_trips_zero(self, admin_token):
        """Create a fresh driver via signup; should appear with zero commission/trips."""
        mobile = f"91{uuid.uuid4().int % 100000000:08d}"
        sr = requests.post(f"{API}/auth/driver/signup", json={
            'name': 'TEST_NoTrips', 'mobile': mobile, 'password': 'Test@1234',
        }, timeout=30)
        # Signup may or may not be available; skip if not
        if sr.status_code not in (200, 201):
            pytest.skip(f"driver signup unavailable: {sr.status_code} {sr.text[:200]}")
        r = requests.get(f"{API}/admin/drivers",
                         headers={'Authorization': f'Bearer {admin_token}'}, timeout=30)
        assert r.status_code == 200
        match = [d for d in r.json() if d.get('mobile') == mobile]
        if not match:
            pytest.skip("newly-created driver not surfaced in /admin/drivers list")
        d = match[0]
        assert d['completed_trips'] == 0
        assert float(d['commission_owed']) == 0.0
