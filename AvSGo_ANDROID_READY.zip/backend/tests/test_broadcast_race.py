"""AvSGo broadcast booking + first-accept-wins race tests.

Covers:
- POST /api/customer/bookings/auto broadcasts to all eligible drivers
- Concurrent accepts: exactly one 200 + N-1 409
- Losing drivers no longer see the booking in /driver/bookings; winner does
- Winner's vehicle_id/plate_no are auto-picked on accept
- 400 'no available vehicle' path
- Reject flow: all-reject transitions status='rejected'
- Manual booking single-driver flow still works (is_broadcast=false, no broadcast_driver_ids)
"""
import os
import uuid
import time
import concurrent.futures as cf
import pytest
import requests

BASE_URL = (os.environ.get('REACT_APP_BACKEND_URL')
            or 'https://book-ride-now-10.preview.emergentagent.com').rstrip('/')
API = f"{BASE_URL}/api"

LAT, LNG = 26.1445, 91.7362
NEAR_LAT, NEAR_LNG = 26.1448, 91.7365


# ---------- helpers ----------
def _login_driver(mobile, password, name='Race Driver'):
    r = requests.post(f"{API}/auth/driver/login",
                      json={'mobile': mobile, 'password': password}, timeout=30)
    if r.status_code == 200:
        return r.json()
    # try register
    r2 = requests.post(f"{API}/auth/driver/register",
                       json={'name': name, 'mobile': mobile, 'password': password}, timeout=30)
    assert r2.status_code == 200, f"register failed: {r2.status_code} {r2.text}"
    return r2.json()


def _all_erickshaw_ids(dtok):
    r = requests.get(f"{API}/driver/vehicles",
                     headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
    assert r.status_code == 200
    return [v['id'] for v in r.json()
            if v['vehicle_type'] == 'E-Rickshaw' and v['status'] == 'approved']


def _set_all_erickshaws(dtok, atok, available):
    """Flip availability for ALL approved E-Rickshaws owned by this driver."""
    for vid in _all_erickshaw_ids(dtok):
        requests.patch(f"{API}/admin/vehicles/{vid}/availability",
                       json={'available': available},
                       headers={'Authorization': f'Bearer {atok}'}, timeout=30)


def _ensure_approved_erickshaw(dtok, atok):
    """Return an approved+available E-Rickshaw vehicle id for driver holding dtok."""
    r = requests.get(f"{API}/driver/vehicles",
                     headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
    assert r.status_code == 200
    for v in r.json():
        if v['vehicle_type'] == 'E-Rickshaw' and v['status'] == 'approved' and v.get('available', True):
            return v['id']
    plate = f"AS02BR{uuid.uuid4().hex[:4].upper()}"
    add = requests.post(f"{API}/driver/vehicles",
                        json={'vehicle_type': 'E-Rickshaw', 'plate_no': plate, 'capacity': '200kg'},
                        headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
    assert add.status_code == 200, add.text
    vid = add.json()['id']
    ap = requests.patch(f"{API}/admin/vehicles/{vid}", json={'action': 'approve'},
                        headers={'Authorization': f'Bearer {atok}'}, timeout=30)
    assert ap.status_code == 200, ap.text
    requests.patch(f"{API}/admin/vehicles/{vid}/availability",
                   json={'available': True},
                   headers={'Authorization': f'Bearer {atok}'}, timeout=30)
    return vid


def _post_location(dtok, lat=LAT, lng=LNG):
    r = requests.post(f"{API}/driver/location",
                      json={'lat': lat, 'lng': lng, 'accuracy': 20},
                      headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
    assert r.status_code == 200, r.text


def _auto_booking(name_suffix='', vt='E-Rickshaw'):
    body = {
        'vehicle_type': vt,
        'customer_name': f'TEST_BC_{name_suffix or uuid.uuid4().hex[:5]}',
        'customer_mobile': '9111100055',
        'pickup': 'Fancy Bazar',
        'drop_location': 'Guwahati Railway Station',
        'distance_km': 3,
        'pickup_lat': NEAR_LAT,
        'pickup_lng': NEAR_LNG,
    }
    return requests.post(f"{API}/customer/bookings/auto", json=body, timeout=30)


# ---------- fixtures ----------
@pytest.fixture(scope='module')
def atok():
    r = requests.post(f"{API}/auth/admin/login",
                      json={'mobile': '9365306642', 'password': 'Jigyasch@98'}, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()['token']


@pytest.fixture(scope='module')
def driver_a(atok):
    j = _login_driver('9000000001', 'Driver@123', name='Test Driver')
    tok = j['token']
    did = j['driver']['id']
    vid = _ensure_approved_erickshaw(tok, atok)
    return {'token': tok, 'id': did, 'vehicle_id': vid, 'mobile': '9000000001'}


@pytest.fixture(scope='module')
def driver_b(atok):
    j = _login_driver('9000000002', 'Driver@123', name='Race Driver')
    tok = j['token']
    did = j['driver']['id']
    vid = _ensure_approved_erickshaw(tok, atok)
    return {'token': tok, 'id': did, 'vehicle_id': vid, 'mobile': '9000000002'}


@pytest.fixture(autouse=True)
def _refresh_locations(driver_a, driver_b):
    _post_location(driver_a['token'])
    _post_location(driver_b['token'])
    yield


# ---------- tests ----------
class TestBroadcastCreate:
    def test_auto_returns_broadcast_fields(self, driver_a, driver_b):
        r = _auto_booking('create')
        assert r.status_code == 200, r.text
        d = r.json()
        assert d['status'] == 'requested'
        assert d['auto_assigned'] is True
        assert d['driver_id'] is None
        assert d['vehicle_id'] is None
        assert d['plate_no'] is None
        assert isinstance(d.get('broadcast_driver_ids'), list)
        assert d['broadcast_count'] == len(d['broadcast_driver_ids'])
        assert d['broadcast_count'] >= 1
        # both drivers should be present since they share the same coords
        assert driver_a['id'] in d['broadcast_driver_ids']
        assert driver_b['id'] in d['broadcast_driver_ids']
        assert 'driver_distance_m' in d and isinstance(d['driver_distance_m'], (int, float))

    def test_broadcast_visible_to_targeted_drivers(self, driver_a, driver_b):
        r = _auto_booking('visible')
        assert r.status_code == 200
        bid = r.json()['id']
        for who in (driver_a, driver_b):
            gb = requests.get(f"{API}/driver/bookings",
                              headers={'Authorization': f"Bearer {who['token']}"}, timeout=30)
            assert gb.status_code == 200
            items = gb.json()
            found = [x for x in items if x['id'] == bid]
            assert found, f"driver {who['id']} should see broadcast {bid}"
            assert found[0]['is_broadcast'] is True
            assert found[0]['mine'] is False


class TestFirstAcceptWinsRace:
    def _accept(self, tok, bid, barrier=None):
        if barrier is not None:
            try:
                barrier.wait(timeout=5)
            except Exception:
                pass
        return requests.patch(f"{API}/driver/bookings/{bid}",
                              json={'action': 'accept'},
                              headers={'Authorization': f'Bearer {tok}'}, timeout=30)

    def test_two_drivers_only_one_wins(self, driver_a, driver_b):
        import threading
        r = _auto_booking('race2')
        assert r.status_code == 200
        bid = r.json()['id']

        barrier = threading.Barrier(2)
        with cf.ThreadPoolExecutor(max_workers=2) as ex:
            futs = [ex.submit(self._accept, driver_a['token'], bid, barrier),
                    ex.submit(self._accept, driver_b['token'], bid, barrier)]
            results = [f.result() for f in futs]

        codes = sorted([r.status_code for r in results])
        # Winner is 200; loser is 409 (ideal) OR 404 (if their initial read happened after write)
        assert 200 in codes, f"expected a winner got {codes}: {[r.text for r in results]}"
        assert len([c for c in codes if c == 200]) == 1, f"multiple winners: {codes}"
        loser_code = [c for c in codes if c != 200][0]
        assert loser_code in (409, 404), f"loser code {loser_code}: {[r.text for r in results]}"

        winner_resp = next(x for x in results if x.status_code == 200)
        w = winner_resp.json()
        assert w['status'] == 'accepted'
        assert w['driver_id'] in (driver_a['id'], driver_b['id'])
        assert w['vehicle_id'] is not None
        assert w['plate_no']

        # DB confirms via customer endpoint
        cs = requests.get(f"{API}/customer/bookings/{bid}", timeout=30)
        assert cs.status_code == 200
        j = cs.json()
        assert j['status'] == 'accepted'
        assert j['driver_id'] == w['driver_id']

        # loser no longer sees the booking; winner does (as mine=True)
        winner_id = w['driver_id']
        winner_tok = driver_a['token'] if winner_id == driver_a['id'] else driver_b['token']
        loser_tok = driver_b['token'] if winner_id == driver_a['id'] else driver_a['token']

        w_list = requests.get(f"{API}/driver/bookings",
                              headers={'Authorization': f'Bearer {winner_tok}'}, timeout=30).json()
        assert any(x['id'] == bid and x.get('mine') is True for x in w_list)
        l_list = requests.get(f"{API}/driver/bookings",
                              headers={'Authorization': f'Bearer {loser_tok}'}, timeout=30).json()
        assert not any(x['id'] == bid for x in l_list), \
            f"loser still sees broadcast booking {bid}"

        # loser gets in-app 'Booking already taken' (best-effort — only sent on 409 branch)
        n = requests.get(f"{API}/inapp/notifications",
                        headers={'Authorization': f'Bearer {loser_tok}'}, timeout=30)
        assert n.status_code == 200

    def test_N_concurrent_accepts_one_wins(self, driver_a, driver_b):
        r = _auto_booking('raceN')
        assert r.status_code == 200
        bid = r.json()['id']
        # 6 parallel calls: 3 from each driver
        toks = [driver_a['token']] * 3 + [driver_b['token']] * 3
        with cf.ThreadPoolExecutor(max_workers=6) as ex:
            futs = [ex.submit(self._accept, t, bid) for t in toks]
            results = [f.result() for f in futs]
        codes = [r.status_code for r in results]
        assert codes.count(200) == 1, f"expected exactly 1 winner, codes={codes}"
        # Other codes may be 409 (broadcast branch loser), 400 (winner double-accept from same driver),
        # or 404 (if some concurrent test flipped state; treat as acceptable non-winners)
        assert all(c in (200, 400, 404, 409) for c in codes), codes
        assert codes.count(409) >= 1


class TestBroadcastCompleteAndCleanup:
    def test_winner_can_complete(self, driver_a, driver_b):
        r = _auto_booking('complete')
        assert r.status_code == 200
        bid = r.json()['id']
        # Driver A accepts first
        ac = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'accept'},
                            headers={'Authorization': f"Bearer {driver_a['token']}"}, timeout=30)
        assert ac.status_code == 200, ac.text
        cp = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'complete'},
                            headers={'Authorization': f"Bearer {driver_a['token']}"}, timeout=30)
        assert cp.status_code == 200, cp.text
        assert cp.json()['status'] == 'completed'


class TestBroadcastNoVehicle:
    def test_400_when_driver_has_no_matching_vehicle(self, atok, driver_a, driver_b):
        """Mark ALL of driver_a's E-Rickshaws unavailable, create broadcast (driver_b + others still eligible),
        then driver_a is not a target — 404 on accept. Driver_b then accepts successfully."""
        _set_all_erickshaws(driver_a['token'], atok, False)
        try:
            r = _auto_booking('noveh')
            assert r.status_code == 200
            d = r.json()
            bid = d['id']
            assert driver_a['id'] not in d['broadcast_driver_ids']
            assert driver_b['id'] in d['broadcast_driver_ids']

            ra = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'accept'},
                                headers={'Authorization': f"Bearer {driver_a['token']}"}, timeout=30)
            assert ra.status_code == 404

            rb = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'accept'},
                                headers={'Authorization': f"Bearer {driver_b['token']}"}, timeout=30)
            assert rb.status_code == 200, rb.text
            assert rb.json()['driver_id'] == driver_b['id']
            assert rb.json()['plate_no']
        finally:
            _set_all_erickshaws(driver_a['token'], atok, True)

    def test_400_when_target_driver_vehicle_flipped_to_unavailable_after_broadcast(
            self, atok, driver_a, driver_b):
        """Create broadcast (driver_a eligible), then flip ALL of driver_a's E-Rickshaws to
        unavailable and have driver_a try to accept — expect 400. driver_b then accepts."""
        r = _auto_booking('flip')
        assert r.status_code == 200
        d = r.json()
        bid = d['id']
        assert driver_a['id'] in d['broadcast_driver_ids']

        _set_all_erickshaws(driver_a['token'], atok, False)
        try:
            ra = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'accept'},
                                headers={'Authorization': f"Bearer {driver_a['token']}"}, timeout=30)
            assert ra.status_code == 400, ra.text
            assert 'no available' in ra.text.lower() or 'E-Rickshaw' in ra.text

            rb = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'accept'},
                                headers={'Authorization': f"Bearer {driver_b['token']}"}, timeout=30)
            assert rb.status_code == 200, rb.text
        finally:
            _set_all_erickshaws(driver_a['token'], atok, True)


class TestBroadcastReject:
    def test_reject_removes_from_list_status_unchanged(self, driver_a, driver_b):
        r = _auto_booking('rejone')
        assert r.status_code == 200
        d = r.json()
        bid = d['id']
        assert driver_a['id'] in d['broadcast_driver_ids']

        rj = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'reject'},
                            headers={'Authorization': f"Bearer {driver_a['token']}"}, timeout=30)
        assert rj.status_code == 200, rj.text
        j = rj.json()
        assert j['status'] == 'requested'
        assert driver_a['id'] not in (j.get('broadcast_driver_ids') or [])
        assert driver_b['id'] in (j.get('broadcast_driver_ids') or [])

    def test_all_reject_transitions_to_rejected(self, atok, driver_a, driver_b):
        """Isolate A+B by marking all OTHER approved E-Rickshaws unavailable, so broadcast
        targets only A and B. After both reject, list is empty -> status='rejected'."""
        # Identify approved E-Rickshaws owned by others and flip them unavailable.
        vlist = requests.get(f"{API}/admin/vehicles",
                             headers={'Authorization': f'Bearer {atok}'}, timeout=30)
        others = []
        if vlist.status_code == 200:
            for v in vlist.json():
                if (v.get('vehicle_type') == 'E-Rickshaw'
                        and v.get('status') == 'approved'
                        and v.get('available', True)
                        and v.get('owner_id') not in (driver_a['id'], driver_b['id'])):
                    others.append(v['id'])
                    requests.patch(f"{API}/admin/vehicles/{v['id']}/availability",
                                   json={'available': False},
                                   headers={'Authorization': f'Bearer {atok}'}, timeout=30)
        try:
            r = _auto_booking('rejall')
            assert r.status_code == 200
            d = r.json()
            bid = d['id']
            # If there are still extra drivers we can't control, skip
            extras = [x for x in d['broadcast_driver_ids']
                      if x not in (driver_a['id'], driver_b['id'])]
            if extras:
                pytest.skip(f"cannot isolate; extra drivers in broadcast: {extras}")

            r1 = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'reject'},
                                headers={'Authorization': f"Bearer {driver_a['token']}"}, timeout=30)
            assert r1.status_code == 200
            r2 = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'reject'},
                                headers={'Authorization': f"Bearer {driver_b['token']}"}, timeout=30)
            assert r2.status_code == 200
            j = r2.json()
            assert j['status'] == 'rejected', j
        finally:
            for vid in others:
                requests.patch(f"{API}/admin/vehicles/{vid}/availability",
                               json={'available': True},
                               headers={'Authorization': f'Bearer {atok}'}, timeout=30)


class TestManualBookingUnchanged:
    def test_manual_single_driver_flow(self, driver_a):
        body = {
            'vehicle_id': driver_a['vehicle_id'],
            'customer_name': 'TEST_ManualBC',
            'customer_mobile': '9111100077',
            'pickup': 'A', 'drop_location': 'B',
            'distance_km': 2,
        }
        r = requests.post(f"{API}/customer/bookings", json=body, timeout=30)
        assert r.status_code == 200, r.text
        j = r.json()
        bid = j['id']
        assert j.get('driver_id') == driver_a['id']
        assert not j.get('broadcast_driver_ids')

        gb = requests.get(f"{API}/driver/bookings",
                          headers={'Authorization': f"Bearer {driver_a['token']}"}, timeout=30)
        assert gb.status_code == 200
        rec = next((x for x in gb.json() if x['id'] == bid), None)
        assert rec is not None
        assert rec['is_broadcast'] is False
        assert rec['mine'] is True

        # accept + complete
        ac = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'accept'},
                            headers={'Authorization': f"Bearer {driver_a['token']}"}, timeout=30)
        assert ac.status_code == 200 and ac.json()['status'] == 'accepted'

        cs = requests.get(f"{API}/customer/bookings/{bid}", timeout=30)
        assert cs.status_code == 200
        assert cs.json()['driver_mobile'] == '9000000001'
        assert cs.json()['status'] == 'accepted'


class TestRegressions:
    def test_push_key(self):
        r = requests.get(f"{API}/push/public-key", timeout=30)
        assert r.status_code == 200 and 'public_key' in r.json()

    def test_admin_stats(self, atok):
        r = requests.get(f"{API}/admin/stats",
                        headers={'Authorization': f'Bearer {atok}'}, timeout=30)
        assert r.status_code == 200

    def test_admin_drivers(self, atok):
        r = requests.get(f"{API}/admin/drivers",
                        headers={'Authorization': f'Bearer {atok}'}, timeout=30)
        assert r.status_code == 200

    def test_inapp_admin(self, atok):
        r = requests.get(f"{API}/inapp/notifications",
                        headers={'Authorization': f'Bearer {atok}'}, timeout=30)
        assert r.status_code == 200 and 'items' in r.json()
