"""AvSGo iteration: GPS driver location + auto-assign nearest driver (POST /api/driver/location, GET /api/driver/location, POST /api/customer/bookings/auto). Also regression on optional pickup_lat/lng on manual booking + existing endpoints."""
import os
import uuid
import pytest
import requests

BASE_URL = (os.environ.get('REACT_APP_BACKEND_URL') or 'https://book-ride-now-10.preview.emergentagent.com').rstrip('/')
API = f"{BASE_URL}/api"

# Guwahati-ish reference point
LAT = 26.1445
LNG = 91.7362
NEAR_LAT = 26.1448  # ~40-60m away
NEAR_LNG = 91.7365


# ---- fixtures ----
@pytest.fixture(scope='module')
def dtok():
    r = requests.post(f"{API}/auth/driver/login", json={'mobile': '9000000001', 'password': 'Driver@123'}, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()['token']


@pytest.fixture(scope='module')
def did(dtok):
    r = requests.post(f"{API}/auth/driver/login", json={'mobile': '9000000001', 'password': 'Driver@123'}, timeout=30)
    return r.json()['driver']['id']


@pytest.fixture(scope='module')
def atok():
    r = requests.post(f"{API}/auth/admin/login", json={'mobile': '9365306642', 'password': 'Jigyasch@98'}, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()['token']


@pytest.fixture(scope='module')
def approved_vehicle(dtok, atok):
    """Ensure driver 9000000001 has an approved E-Rickshaw with available=true."""
    # Try existing first
    r = requests.get(f"{API}/driver/vehicles", headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
    assert r.status_code == 200
    for v in r.json():
        if v['vehicle_type'] == 'E-Rickshaw' and v['status'] == 'approved' and v.get('available', True):
            return v['id']

    # Create + approve a new one
    plate = f"AS02AU{uuid.uuid4().hex[:4].upper()}"
    add = requests.post(f"{API}/driver/vehicles",
                        json={'vehicle_type': 'E-Rickshaw', 'plate_no': plate, 'capacity': '200kg'},
                        headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
    assert add.status_code == 200, add.text
    vid = add.json()['id']
    ap = requests.patch(f"{API}/admin/vehicles/{vid}", json={'action': 'approve'},
                        headers={'Authorization': f'Bearer {atok}'}, timeout=30)
    assert ap.status_code == 200
    # ensure available
    requests.patch(f"{API}/admin/vehicles/{vid}/availability", json={'available': True},
                   headers={'Authorization': f'Bearer {atok}'}, timeout=30)
    return vid


# ---- driver/location ----
class TestDriverLocation:
    def test_no_token_returns_401_or_403(self):
        r = requests.post(f"{API}/driver/location", json={'lat': LAT, 'lng': LNG}, timeout=30)
        assert r.status_code in (401, 403)

    def test_admin_token_forbidden(self, atok):
        r = requests.post(f"{API}/driver/location", json={'lat': LAT, 'lng': LNG},
                          headers={'Authorization': f'Bearer {atok}'}, timeout=30)
        assert r.status_code == 403

    def test_invalid_coords(self, dtok):
        r = requests.post(f"{API}/driver/location", json={'lat': 99, 'lng': LNG},
                          headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        assert r.status_code == 400

    def test_update_and_get(self, dtok):
        r = requests.post(f"{API}/driver/location",
                          json={'lat': LAT, 'lng': LNG, 'accuracy': 25},
                          headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d.get('ok') is True
        assert abs(d['lat'] - LAT) < 1e-6 and abs(d['lng'] - LNG) < 1e-6

        g = requests.get(f"{API}/driver/location",
                         headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        assert g.status_code == 200
        dg = g.json()
        assert abs(dg['lat'] - LAT) < 1e-6
        assert abs(dg['lng'] - LNG) < 1e-6
        assert dg['accuracy'] == 25
        assert dg['updated_at'] is not None


# ---- customer/bookings/auto ----
class TestAutoAssign:
    def _base_body(self, **kw):
        b = {
            'vehicle_type': 'E-Rickshaw',
            'customer_name': 'TEST_Auto',
            'customer_mobile': '9111100022',
            'pickup': 'Near Fancy Bazar',
            'drop_location': 'Guwahati Railway Station',
            'distance_km': 3,
            'pickup_lat': NEAR_LAT,
            'pickup_lng': NEAR_LNG,
        }
        b.update(kw)
        return b

    def test_success_finds_nearest_driver(self, dtok, did, approved_vehicle):
        # Ensure driver location is fresh
        requests.post(f"{API}/driver/location", json={'lat': LAT, 'lng': LNG, 'accuracy': 20},
                      headers={'Authorization': f'Bearer {dtok}'}, timeout=30)

        r = requests.post(f"{API}/customer/bookings/auto", json=self._base_body(), timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d['status'] == 'requested'
        assert d['vehicle_type'] == 'E-Rickshaw'
        assert d['auto_assigned'] is True
        # Broadcast: driver_id is None until first driver accepts
        assert d['driver_id'] is None
        assert d.get('vehicle_id') is None
        assert d.get('plate_no') is None
        assert isinstance(d.get('broadcast_driver_ids'), list) and did in d['broadcast_driver_ids']
        assert d['id']
        assert 'driver_distance_m' in d
        assert isinstance(d['driver_distance_m'], (int, float))
        # NEAR is ~50m from ref; well under 500m
        assert 0 <= d['driver_distance_m'] < 500
        assert abs(d['pickup_lat'] - NEAR_LAT) < 1e-6
        assert abs(d['pickup_lng'] - NEAR_LNG) < 1e-6

    def test_driver_receives_inapp_notification(self, dtok, did, approved_vehicle):
        requests.post(f"{API}/driver/location", json={'lat': LAT, 'lng': LNG, 'accuracy': 20},
                      headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        r = requests.post(f"{API}/customer/bookings/auto", json=self._base_body(customer_name='TEST_AutoNotif'), timeout=30)
        assert r.status_code == 200

        # driver inapp
        n = requests.get(f"{API}/inapp/notifications",
                         headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        assert n.status_code == 200
        items = n.json()['items']
        titles = [i.get('title', '') for i in items]
        assert any('New booking request (near you)' in t for t in titles), titles[:5]

    def test_admin_receives_inapp_notification(self, atok, dtok, approved_vehicle):
        requests.post(f"{API}/driver/location", json={'lat': LAT, 'lng': LNG, 'accuracy': 20},
                      headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        marker = f"TEST_AdmNotif_{uuid.uuid4().hex[:6]}"
        r = requests.post(f"{API}/customer/bookings/auto", json=self._base_body(customer_name=marker), timeout=30)
        assert r.status_code == 200

        n = requests.get(f"{API}/inapp/notifications",
                         headers={'Authorization': f'Bearer {atok}'}, timeout=30)
        assert n.status_code == 200
        items = n.json()['items']
        assert any(marker in (i.get('body') or '') or 'Auto-assigned booking' == i.get('title')
                   for i in items), items[:3]

    def test_no_driver_far_coords(self, dtok, approved_vehicle):
        # Force location refresh so freshness ok — but we ask at (0,0), far away
        requests.post(f"{API}/driver/location", json={'lat': LAT, 'lng': LNG},
                      headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        r = requests.post(f"{API}/customer/bookings/auto",
                         json=self._base_body(pickup_lat=0.0, pickup_lng=0.0), timeout=30)
        assert r.status_code == 404
        assert 'No online drivers' in r.text or 'No E-Rickshaw' in r.text

    def test_small_radius_returns_404(self, dtok, approved_vehicle):
        requests.post(f"{API}/driver/location", json={'lat': LAT, 'lng': LNG},
                      headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        # ~500m away with radius = 0.1 km (100m) should exclude
        r = requests.post(f"{API}/customer/bookings/auto",
                         json=self._base_body(pickup_lat=26.15, pickup_lng=91.74, max_radius_km=0.1),
                         timeout=30)
        assert r.status_code == 404

    def test_no_vehicle_type_available(self, dtok, approved_vehicle):
        # driver has no Tractor — nearest driver has no Tractor vehicle
        requests.post(f"{API}/driver/location", json={'lat': LAT, 'lng': LNG},
                      headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        r = requests.post(f"{API}/customer/bookings/auto",
                         json=self._base_body(vehicle_type='Tractor'), timeout=30)
        assert r.status_code == 404
        assert 'Tractor' in r.text

    # validation
    def test_validate_bad_vehicle_type(self):
        r = requests.post(f"{API}/customer/bookings/auto",
                         json=self._base_body(vehicle_type='Bus'), timeout=30)
        assert r.status_code == 400

    def test_validate_bad_distance(self):
        r = requests.post(f"{API}/customer/bookings/auto",
                         json=self._base_body(distance_km=0), timeout=30)
        assert r.status_code == 400

    def test_validate_bad_mobile(self):
        r = requests.post(f"{API}/customer/bookings/auto",
                         json=self._base_body(customer_mobile='12345'), timeout=30)
        assert r.status_code == 400

    def test_validate_bad_coords(self):
        r = requests.post(f"{API}/customer/bookings/auto",
                         json=self._base_body(pickup_lat=95.0), timeout=30)
        assert r.status_code == 400

    def test_respects_availability_flag(self, dtok, atok, approved_vehicle):
        """Mark the driver's only E-Rickshaw as available=false — auto should now return 404 (Tractor test showed no other driver)."""
        requests.post(f"{API}/driver/location", json={'lat': LAT, 'lng': LNG},
                      headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        # Mark unavailable
        u = requests.patch(f"{API}/admin/vehicles/{approved_vehicle}/availability",
                           json={'available': False},
                           headers={'Authorization': f'Bearer {atok}'}, timeout=30)
        assert u.status_code == 200
        try:
            r = requests.post(f"{API}/customer/bookings/auto", json=self._base_body(), timeout=30)
            # Should skip this vehicle; either 404 or if some other driver happens to have E-Rickshaw
            if r.status_code == 200:
                assert r.json()['vehicle_id'] != approved_vehicle
            else:
                assert r.status_code == 404
        finally:
            requests.patch(f"{API}/admin/vehicles/{approved_vehicle}/availability",
                           json={'available': True},
                           headers={'Authorization': f'Bearer {atok}'}, timeout=30)

    def test_accept_flow_on_auto_booking(self, dtok, did, approved_vehicle):
        requests.post(f"{API}/driver/location", json={'lat': LAT, 'lng': LNG},
                      headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        r = requests.post(f"{API}/customer/bookings/auto",
                         json=self._base_body(customer_mobile='9111100099', customer_name='TEST_AutoAccept'),
                         timeout=30)
        assert r.status_code == 200, r.text
        bid = r.json()['id']

        ac = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'accept'},
                            headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        assert ac.status_code == 200 and ac.json()['status'] == 'accepted'

        cs = requests.get(f"{API}/customer/bookings/{bid}", timeout=30)
        assert cs.status_code == 200
        j = cs.json()
        assert j['driver_mobile'] == '9000000001'
        assert 'driver_distance_m' in j

        cp = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'complete'},
                            headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        assert cp.status_code == 200 and cp.json()['status'] == 'completed'


# ---- manual booking pickup_lat/lng regression ----
class TestManualBookingPickupCoords:
    def test_manual_with_coords_persisted(self, approved_vehicle):
        body = {
            'vehicle_id': approved_vehicle,
            'customer_name': 'TEST_ManualCoord',
            'customer_mobile': '9111100033',
            'pickup': 'A', 'drop_location': 'B',
            'distance_km': 4,
            'pickup_lat': 26.1450,
            'pickup_lng': 91.7370,
        }
        r = requests.post(f"{API}/customer/bookings", json=body, timeout=30)
        assert r.status_code == 200, r.text
        j = r.json()
        assert j.get('pickup_lat') == 26.1450
        assert j.get('pickup_lng') == 91.7370

    def test_manual_without_coords_ok(self, approved_vehicle):
        body = {
            'vehicle_id': approved_vehicle,
            'customer_name': 'TEST_ManualNoCoord',
            'customer_mobile': '9111100044',
            'pickup': 'A', 'drop_location': 'B',
            'distance_km': 2,
        }
        r = requests.post(f"{API}/customer/bookings", json=body, timeout=30)
        assert r.status_code == 200, r.text


# ---- Regressions ----
class TestRegressions:
    def test_fare_settings(self):
        r = requests.get(f"{API}/fare-settings", timeout=30)
        assert r.status_code == 200 and len(r.json()) >= 4

    def test_admin_stats(self, atok):
        r = requests.get(f"{API}/admin/stats", headers={'Authorization': f'Bearer {atok}'}, timeout=30)
        assert r.status_code == 200
        for k in ('drivers', 'pending_vehicles', 'completed_trips', 'revenue', 'commission_earned', 'upi'):
            assert k in r.json()

    def test_admin_drivers(self, atok):
        r = requests.get(f"{API}/admin/drivers", headers={'Authorization': f'Bearer {atok}'}, timeout=30)
        assert r.status_code == 200 and isinstance(r.json(), list)

    def test_inapp_notifications_admin(self, atok):
        r = requests.get(f"{API}/inapp/notifications", headers={'Authorization': f'Bearer {atok}'}, timeout=30)
        assert r.status_code == 200
        d = r.json()
        assert 'items' in d and 'unread' in d

    def test_push_public_key(self):
        r = requests.get(f"{API}/push/public-key", timeout=30)
        assert r.status_code == 200 and 'public_key' in r.json()
