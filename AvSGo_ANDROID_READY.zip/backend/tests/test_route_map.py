"""Backend tests for the new customer map/routing flow (iteration 15).

Covers:
- POST /api/route with real OSRM road distance + geometry + fare
- POST /api/route coord validation (400)
- GET /api/reverse-geocode success and validation
- GET /api/geocode still works (search box)
- Regression: /api/public/vehicles, /api/fare-settings, /api/upi,
  admin login, driver login, POST /api/customer/bookings (manual),
  POST /api/customer/bookings/auto (auto broadcast)
"""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
if not BASE_URL:
    # Fallback to reading from frontend env file (test env)
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.split("=", 1)[1].strip()
                break
BASE_URL = BASE_URL.rstrip("/")
API = f"{BASE_URL}/api"

# Guwahati / Dispur — real road distance ~6-10 km in Assam
GUWAHATI = (26.1445, 91.7362)
DISPUR = (26.1433, 91.7898)


# ---------- /api/route ----------
class TestRoute:
    def test_route_osrm_success(self):
        r = requests.post(f"{API}/route", json={
            "pickup_lat": GUWAHATI[0], "pickup_lng": GUWAHATI[1],
            "drop_lat": DISPUR[0], "drop_lng": DISPUR[1],
            "vehicle_type": "E-Rickshaw",
        }, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["method"] in ("osrm", "ors"), f"method={data['method']} must not be haversine"
        assert data["method"] != "haversine"
        assert isinstance(data["distance_km"], (int, float))
        assert data["distance_km"] > 0
        assert isinstance(data["duration_min"], (int, float))
        assert isinstance(data["geometry"], list) and len(data["geometry"]) >= 2
        # geometry entries are [lat,lng]
        p0 = data["geometry"][0]
        assert isinstance(p0, list) and len(p0) == 2
        assert -90 <= p0[0] <= 90 and -180 <= p0[1] <= 180
        # fare fields
        assert "fare" in data and data["fare"] > 0
        assert "base_fare" in data and "per_km" in data
        assert data["vehicle_type"] == "E-Rickshaw"

    def test_route_short_distance_nonzero(self):
        # ~200m offset
        r = requests.post(f"{API}/route", json={
            "pickup_lat": 26.1445, "pickup_lng": 91.7362,
            "drop_lat": 26.1463, "drop_lng": 91.7362,
        }, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["distance_km"] > 0
        assert data["method"] != "haversine"

    def test_route_invalid_lat(self):
        r = requests.post(f"{API}/route", json={
            "pickup_lat": 999, "pickup_lng": 91.7,
            "drop_lat": 26.1, "drop_lng": 91.7,
        }, timeout=15)
        assert r.status_code == 400

    def test_route_invalid_lng(self):
        r = requests.post(f"{API}/route", json={
            "pickup_lat": 26.1, "pickup_lng": 999,
            "drop_lat": 26.2, "drop_lng": 91.7,
        }, timeout=15)
        assert r.status_code == 400


# ---------- /api/reverse-geocode & /api/geocode ----------
class TestGeocoding:
    def test_reverse_geocode_ok(self):
        r = requests.get(f"{API}/reverse-geocode",
                         params={"lat": GUWAHATI[0], "lng": GUWAHATI[1]}, timeout=20)
        assert r.status_code == 200, r.text
        data = r.json()
        assert "display_name" in data
        assert data["lat"] == GUWAHATI[0]
        assert data["lng"] == GUWAHATI[1]

    def test_reverse_geocode_invalid(self):
        r = requests.get(f"{API}/reverse-geocode",
                         params={"lat": 999, "lng": 0}, timeout=15)
        assert r.status_code == 400

    def test_geocode_search(self):
        r = requests.get(f"{API}/geocode", params={"q": "Guwahati"}, timeout=20)
        assert r.status_code == 200
        data = r.json()
        assert "results" in data
        # Nominatim may occasionally return empty; allow it but require list
        assert isinstance(data["results"], list)


# ---------- Regression: public endpoints ----------
class TestRegression:
    def test_public_vehicles(self):
        r = requests.get(f"{API}/public/vehicles", timeout=15)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_fare_settings(self):
        r = requests.get(f"{API}/fare-settings", timeout=15)
        assert r.status_code == 200
        data = r.json()
        # Expect at least the four vehicle types
        types = {row["vehicle_type"] for row in (data if isinstance(data, list) else data.get("items", []))}
        assert "erickshaw" in types or len(types) >= 1

    def test_upi_public(self):
        r = requests.get(f"{API}/upi", timeout=15)
        assert r.status_code == 200
        assert "upi" in r.json()

    def test_admin_login(self):
        r = requests.post(f"{API}/auth/admin/login",
                         json={"mobile": "9365306642", "password": "Jigyasch@98"}, timeout=15)
        assert r.status_code == 200, r.text
        assert "token" in r.json()

    def test_driver_login(self):
        r = requests.post(f"{API}/auth/driver/login",
                         json={"mobile": "9000000001", "password": "Driver@123"}, timeout=15)
        assert r.status_code == 200, r.text
        assert "token" in r.json()


# ---------- Regression: customer booking flows ----------
class TestCustomerBookings:
    def test_create_manual_booking(self):
        # Need a driver's approved vehicle. Fetch public list.
        vehicles = requests.get(f"{API}/public/vehicles", timeout=15).json()
        if not vehicles:
            pytest.skip("No public vehicles seeded")
        v = vehicles[0]
        payload = {
            "customer_name": "TEST_Cust",
            "customer_mobile": "9999900001",
            "vehicle_id": v["id"],
            "pickup": "Guwahati",
            "drop_location": "Dispur",
            "pickup_lat": GUWAHATI[0], "pickup_lng": GUWAHATI[1],
            "distance_km": 6.5,
        }
        r = requests.post(f"{API}/customer/bookings", json=payload, timeout=20)
        # Accept 200/201; if backend requires different fields, capture body
        assert r.status_code in (200, 201), f"{r.status_code}: {r.text}"
        data = r.json()
        assert "id" in data or "booking" in data

    def test_create_auto_booking(self):
        payload = {
            "customer_name": "TEST_CustAuto",
            "customer_mobile": "9999900002",
            "vehicle_type": "E-Rickshaw",
            "pickup": "Guwahati",
            "drop_location": "Dispur",
            "pickup_lat": GUWAHATI[0], "pickup_lng": GUWAHATI[1],
            "distance_km": 6.5,
        }
        r = requests.post(f"{API}/customer/bookings/auto", json=payload, timeout=20)
        # 404 acceptable when no online drivers seeded — endpoint still functional
        assert r.status_code in (200, 201, 404), f"{r.status_code}: {r.text}"
