"""Tests for /api/places/autocomplete (Photon + Nominatim fallback) - iter18."""
import os
import time
import requests
import pytest

def _load_url():
    v = os.environ.get('REACT_APP_BACKEND_URL')
    if not v:
        try:
            for line in open('/app/frontend/.env'):
                if line.startswith('REACT_APP_BACKEND_URL='):
                    v = line.split('=', 1)[1].strip()
                    break
        except Exception:
            pass
    return (v or '').rstrip('/')

BASE_URL = _load_url()
AC = f"{BASE_URL}/api/places/autocomplete"


def _get(params):
    time.sleep(0.6)  # respect Photon soft rate-limit
    return requests.get(AC, params=params, timeout=20)


class TestPlacesAutocomplete:
    def test_bihpuria_first_letter_784161(self):
        """PIN 784161: single 'B' should return Bihpuria-area results."""
        params = {
            'q': 'B',
            'west': 93.8891535, 'south': 26.9781107,
            'east': 93.9899516, 'north': 27.0683842,
            'lat': 27.0232, 'lng': 93.9395,
        }
        r = _get(params)
        assert r.status_code == 200, r.text
        data = r.json()
        assert 'results' in data and 'source' in data
        assert data['source'] in ('photon', 'nominatim')
        assert len(data['results']) >= 1
        # First result should contain 'Bihpuria' (or fallback ok)
        joined = ' '.join(x['display_name'] or '' for x in data['results']).lower()
        assert 'bihpuria' in joined, f"'Bihpuria' not in results: {joined[:400]}"
        # Coordinate validation
        for r_ in data['results']:
            assert isinstance(r_['lat'], float) and isinstance(r_['lng'], float)

    def test_guwahati_single_letter_S(self):
        """PIN 781001 Guwahati bbox: 'S' should give 5+ local results."""
        params = {
            'q': 'S',
            'west': 91.6982453, 'south': 26.1310208,
            'east': 91.7982935, 'north': 26.2212955,
            'lat': 26.1445, 'lng': 91.7362,
        }
        r = _get(params)
        assert r.status_code == 200
        data = r.json()
        assert data['source'] in ('photon', 'nominatim')
        assert len(data['results']) >= 5, f"expected 5+ got {len(data['results'])}"
        # Should be geographically near Guwahati (bbox strict)
        for row in data['results']:
            assert 25.5 < row['lat'] < 27.0, f"outside Guwahati bbox: {row}"
            assert 91.0 < row['lng'] < 92.5

    def test_bbox_strict_no_global_leak(self):
        """With bbox, results must stay inside/near bbox — no country-wide leak."""
        params = {
            'q': 'Bihpuria',
            'west': 91.6982453, 'south': 26.1310208,
            'east': 91.7982935, 'north': 26.2212955,
            'lat': 26.1445, 'lng': 91.7362,
        }
        r = _get(params)
        assert r.status_code == 200
        data = r.json()
        # Bihpuria is not in Guwahati bbox → strict bbox → may fallback nominatim / widened photon.
        # We only assert response shape; if any results, they must not be from Delhi etc.
        for row in data['results']:
            # allow widened-bbox (1.8x) results but not truly global
            assert 24.0 < row['lat'] < 29.0, f"suspiciously global: {row}"

    def test_bi_prefix_refines(self):
        params = {
            'q': 'Bi',
            'west': 93.8891535, 'south': 26.9781107,
            'east': 93.9899516, 'north': 27.0683842,
            'lat': 27.0232, 'lng': 93.9395,
        }
        r = _get(params)
        assert r.status_code == 200
        assert len(r.json()['results']) >= 1

    def test_min_length_one(self):
        # 'q' min_length=1 → empty should 422
        r = requests.get(AC, params={'q': ''}, timeout=10)
        assert r.status_code == 422


class TestRuralPIN784160:
    """Iter19: rural PIN 784160 (Bihpuria/Lakhimpur area) — the regression case.
    Old widening (1.8x) returned only 1 result for 'L'; new 1x/3x/6x/12x must give >=5."""

    BBOX = {
        'west': 93.8770499, 'south': 27.0612184,
        'east': 93.9779227, 'north': 27.1514912,
        'lat': 27.106355, 'lng': 93.9274867,
        'limit': 10,
    }

    def test_L_returns_lakhimpur_places(self):
        r = _get({'q': 'L', **self.BBOX})
        assert r.status_code == 200, r.text
        d = r.json()
        assert d['source'] == 'photon', f"source={d.get('source')}"
        assert d['count'] >= 5, f"expected >=5 got {d['count']}: {d}"
        joined = ' '.join((x['display_name'] or '') for x in d['results']).lower()
        # Must contain some Lakhimpur/Laluk content — proves not global
        assert ('lakhimpur' in joined) or ('laluk' in joined), f"no lakhimpur/laluk in: {joined[:500]}"

    def test_La_refines(self):
        r = _get({'q': 'La', **self.BBOX})
        assert r.status_code == 200
        d = r.json()
        assert d['count'] >= 5, f"expected >=5 got {d['count']}"
        joined = ' '.join((x['display_name'] or '') for x in d['results']).lower()
        assert ('lakhimpur' in joined) or ('laluk' in joined)

    def test_S_local_results(self):
        r = _get({'q': 'S', **self.BBOX})
        assert r.status_code == 200
        d = r.json()
        assert d['count'] >= 5, f"expected >=5 got {d['count']}"
        # All within North-Assam broader box
        for row in d['results']:
            assert 26.0 < row['lat'] < 28.0, f"out of region: {row}"
            assert 93.0 < row['lng'] < 95.0

    def test_H_local_results(self):
        r = _get({'q': 'H', **self.BBOX})
        assert r.status_code == 200
        d = r.json()
        assert d['count'] >= 5, f"expected >=5 got {d['count']}"

    def test_dedup_by_coords(self):
        r = _get({'q': 'L', **self.BBOX})
        d = r.json()
        coords = [(round(x['lat'], 5), round(x['lng'], 5)) for x in d['results']]
        assert len(coords) == len(set(coords)), "duplicate coordinates present"


class TestDenseCityRegression:
    """Rural widening must NOT contaminate dense-city PIN results."""

    def test_guwahati_S_is_local(self):
        params = {
            'q': 'S',
            'west': 91.6982453, 'south': 26.1310208,
            'east': 91.7982935, 'north': 26.2212955,
            'lat': 26.1445, 'lng': 91.7362, 'limit': 10,
        }
        r = _get(params)
        d = r.json()
        assert d['count'] >= 5
        # nearest-first: top result must be very close to bias (< ~10km)
        top = d['results'][0]
        assert 26.0 < top['lat'] < 26.35, f"top not Guwahati-local: {top}"
        assert 91.5 < top['lng'] < 91.95

    def test_delhi_pin_110001(self):
        # New Delhi (Connaught Place) PIN
        params = {
            'q': 'C',
            'west': 77.20, 'south': 28.60,
            'east': 77.24, 'north': 28.64,
            'lat': 28.6289, 'lng': 77.2065, 'limit': 10,
        }
        r = _get(params)
        d = r.json()
        assert d['count'] >= 3, f"expected >=3, got {d}"
        for row in d['results']:
            assert 28.0 < row['lat'] < 29.2, f"leak outside Delhi: {row}"
            assert 76.5 < row['lng'] < 77.8


class TestRegression:
    def test_geocode(self):
        r = requests.get(f"{BASE_URL}/api/geocode", params={'q': 'Guwahati'}, timeout=15)
        assert r.status_code == 200
        assert 'results' in r.json()

    def test_pincode_valid(self):
        r = requests.get(f"{BASE_URL}/api/pincode/781001", timeout=20)
        assert r.status_code == 200
        d = r.json()
        assert 'lat' in d and 'lng' in d

    def test_pincode_784160(self):
        r = requests.get(f"{BASE_URL}/api/pincode/784160", timeout=20)
        assert r.status_code == 200
        d = r.json()
        assert 'lat' in d and 'lng' in d
        # Basic bbox sanity
        assert 26.5 < d['lat'] < 27.6

    def test_pincode_110001(self):
        r = requests.get(f"{BASE_URL}/api/pincode/110001", timeout=20)
        assert r.status_code == 200

    def test_pincode_invalid(self):
        r = requests.get(f"{BASE_URL}/api/pincode/999999", timeout=20)
        assert r.status_code in (400, 404)

    def test_reverse_geocode(self):
        r = requests.get(f"{BASE_URL}/api/reverse-geocode",
                         params={'lat': 26.1445, 'lng': 91.7362}, timeout=15)
        assert r.status_code == 200

    def test_route(self):
        r = requests.post(f"{BASE_URL}/api/route",
                          json={'pickup_lat': 26.1445, 'pickup_lng': 91.7362,
                                'drop_lat': 26.1800, 'drop_lng': 91.7500}, timeout=20)
        assert r.status_code == 200, r.text
        d = r.json()
        assert 'distance_km' in d or 'distance' in d
