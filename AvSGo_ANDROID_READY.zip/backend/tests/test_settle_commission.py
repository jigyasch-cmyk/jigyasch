"""Tests for AvSGo owner payout / settle-commission flow."""
import os
import time
import pytest
import requests

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'https://book-ride-now-10.preview.emergentagent.com').rstrip('/')
API = f"{BASE_URL}/api"

ADMIN = {'mobile': '9365306642', 'password': 'Jigyasch@98'}
DRIVER = {'mobile': '9000000001', 'password': 'Driver@123'}


@pytest.fixture(scope='module')
def admin_token():
    r = requests.post(f"{API}/auth/admin/login", json=ADMIN, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()['token']


@pytest.fixture(scope='module')
def driver_token():
    r = requests.post(f"{API}/auth/driver/login", json=DRIVER, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()['token']


def _h(tok):
    return {'Authorization': f'Bearer {tok}'}


@pytest.fixture(scope='module')
def test_driver_id(admin_token):
    r = requests.get(f"{API}/admin/drivers", headers=_h(admin_token), timeout=15)
    assert r.status_code == 200
    drivers = r.json()
    for d in drivers:
        if d.get('mobile') == DRIVER['mobile']:
            return d['id']
    pytest.skip("Test Driver not found")


# --- state container to share between ordered tests ---
STATE = {}


def test_1_driver_commission_shape_before_settle(driver_token):
    r = requests.get(f"{API}/driver/commission", headers=_h(driver_token), timeout=15)
    assert r.status_code == 200
    data = r.json()
    for k in ('commission_owed', 'commission_paid', 'total_earnings', 'trips', 'upi'):
        assert k in data, f"missing {k}"
    STATE['pre_owed'] = data['commission_owed']
    STATE['pre_paid'] = data['commission_paid']
    STATE['pre_earnings'] = data['total_earnings']
    print("pre-settle commission:", data)


def test_2_settle_requires_admin_auth(test_driver_id, driver_token):
    # no token
    r = requests.post(f"{API}/admin/drivers/{test_driver_id}/settle-commission", timeout=15)
    assert r.status_code in (401, 403), r.status_code
    # driver token
    r = requests.post(
        f"{API}/admin/drivers/{test_driver_id}/settle-commission",
        headers=_h(driver_token), timeout=15,
    )
    assert r.status_code in (401, 403), r.status_code


def test_3_settle_success(admin_token, test_driver_id):
    if STATE.get('pre_owed', 0) <= 0:
        pytest.skip("No pending commission to settle for Test Driver")
    r = requests.post(
        f"{API}/admin/drivers/{test_driver_id}/settle-commission",
        headers=_h(admin_token), timeout=15,
    )
    assert r.status_code == 200, r.text
    data = r.json()
    assert data.get('ok') is True
    assert data.get('amount') == STATE['pre_owed']
    assert data.get('trips', 0) >= 1
    assert 'payout_id' in data
    STATE['settled_amount'] = data['amount']
    STATE['payout_id'] = data['payout_id']


def test_4_settle_second_time_returns_400(admin_token, test_driver_id):
    r = requests.post(
        f"{API}/admin/drivers/{test_driver_id}/settle-commission",
        headers=_h(admin_token), timeout=15,
    )
    assert r.status_code == 400, r.text
    assert 'No pending commission' in r.text


def test_5_admin_drivers_owed_zero(admin_token, test_driver_id):
    r = requests.get(f"{API}/admin/drivers", headers=_h(admin_token), timeout=15)
    assert r.status_code == 200
    row = next((d for d in r.json() if d['id'] == test_driver_id), None)
    assert row is not None
    assert row.get('commission_owed', 0) == 0, row
    assert row.get('completed_trips', 0) == 0, row


def test_6_driver_commission_after_settle(driver_token):
    r = requests.get(f"{API}/driver/commission", headers=_h(driver_token), timeout=15)
    assert r.status_code == 200
    data = r.json()
    assert data['commission_owed'] == 0
    if 'settled_amount' in STATE:
        assert data['commission_paid'] == STATE['settled_amount'] + STATE.get('pre_paid', 0)
    # total earnings unchanged
    assert data['total_earnings'] == STATE['pre_earnings']


def test_7_payouts_list(admin_token, test_driver_id):
    r = requests.get(f"{API}/admin/drivers/{test_driver_id}/payouts", headers=_h(admin_token), timeout=15)
    assert r.status_code == 200
    items = r.json()
    assert isinstance(items, list) and len(items) >= 1
    p = items[0]
    for k in ('id', 'driver_id', 'driver_name', 'amount', 'trips', 'paid_at'):
        assert k in p, f"missing key {k} in payout"
    # sorted desc by paid_at
    if len(items) > 1:
        assert items[0]['paid_at'] >= items[1]['paid_at']


def test_8_inapp_notification_commission_cleared(driver_token):
    r = requests.get(f"{API}/inapp/notifications", headers=_h(driver_token), timeout=15)
    assert r.status_code == 200
    items = r.json().get('items', [])
    titles = [i.get('title') for i in items]
    assert 'Commission cleared' in titles, titles


def test_9_admin_stats_still_works(admin_token):
    r = requests.get(f"{API}/admin/stats", headers=_h(admin_token), timeout=15)
    assert r.status_code == 200
    data = r.json()
    assert 'revenue' in data or 'total_revenue' in data or 'commission_earned' in data, data


def test_10_settle_unknown_driver(admin_token):
    r = requests.post(
        f"{API}/admin/drivers/nonexistent-id/settle-commission",
        headers=_h(admin_token), timeout=15,
    )
    assert r.status_code == 404
