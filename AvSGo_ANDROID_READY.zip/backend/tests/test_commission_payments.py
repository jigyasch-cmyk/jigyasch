"""Tests for AvSGo Commission Payment System (driver-submits, admin-approves)."""
import os
import uuid
import pytest
import requests

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'https://book-ride-now-10.preview.emergentagent.com').rstrip('/')
API = f"{BASE_URL}/api"

ADMIN = {'mobile': '9365306642', 'password': 'Jigyasch@98'}
DRIVER = {'mobile': '9000000001', 'password': 'Driver@123'}


def _h(tok):
    return {'Authorization': f'Bearer {tok}'}


@pytest.fixture(scope='module')
def admin_token():
    r = requests.post(f"{API}/auth/admin/login", json=ADMIN, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()['token']


@pytest.fixture(scope='module')
def driver_token():
    r = requests.post(f"{API}/auth/driver/login", json=DRIVER, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()['token']


@pytest.fixture(scope='module')
def driver_id(admin_token):
    r = requests.get(f"{API}/admin/drivers", headers=_h(admin_token), timeout=15)
    assert r.status_code == 200
    for d in r.json():
        if d.get('mobile') == DRIVER['mobile']:
            return d['id']
    pytest.skip("Test Driver not found")


@pytest.fixture(scope='module')
def approved_vehicle(admin_token, driver_token):
    """Ensure the seed driver has at least one approved E-Rickshaw."""
    # Look for existing approved vehicle
    r = requests.get(f"{API}/driver/vehicles", headers=_h(driver_token), timeout=15)
    if r.status_code == 200:
        for v in r.json():
            if v.get('status') == 'approved' and v.get('vehicle_type') == 'E-Rickshaw':
                return v['id']
    plate = f"AS02CP{uuid.uuid4().hex[:4].upper()}"
    add = requests.post(f"{API}/driver/vehicles",
                        json={'vehicle_type': 'E-Rickshaw', 'plate_no': plate, 'capacity': '200kg'},
                        headers=_h(driver_token), timeout=15)
    assert add.status_code == 200, add.text
    vid = add.json()['id']
    ap = requests.patch(f"{API}/admin/vehicles/{vid}", json={'action': 'approve'},
                        headers=_h(admin_token), timeout=15)
    assert ap.status_code == 200
    return vid


def _seed_completed_trips(driver_token, vehicle_id, n=5, distance_km=5):
    """Create n completed bookings to accrue commission. Returns list of commissions."""
    commissions = []
    for i in range(n):
        body = {
            'vehicle_id': vehicle_id,
            'customer_name': f'TEST_Cust_{uuid.uuid4().hex[:6]}',
            'customer_mobile': '9111100011',
            'pickup': 'A', 'drop_location': 'B',
            'distance_km': distance_km,
        }
        cr = requests.post(f"{API}/customer/bookings", json=body, timeout=15)
        assert cr.status_code == 200, cr.text
        bk = cr.json()
        bid = bk['id']
        commissions.append(bk['commission'])
        ac = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'accept'},
                            headers=_h(driver_token), timeout=15)
        assert ac.status_code == 200
        cp = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'complete'},
                            headers=_h(driver_token), timeout=15)
        assert cp.status_code == 200 and cp.json()['status'] == 'completed'
    return commissions


def _clear_owed(admin_token, did):
    """Use legacy settle endpoint to zero out current owed."""
    r = requests.post(f"{API}/admin/drivers/{did}/settle-commission",
                      headers=_h(admin_token), timeout=15)
    # 200 if there was owed, 400 if already zero — both fine.
    assert r.status_code in (200, 400)


# ------------------------- 1) /api/upi + QR asset -------------------------

def test_upi_public_no_auth():
    r = requests.get(f"{API}/upi", timeout=15)
    assert r.status_code == 200
    data = r.json()
    assert data['upi'] == '9365306642@axisbank'
    assert data['qr_url'] == '/upi-qr.jpeg'


def test_upi_qr_asset_served():
    r = requests.get(f"{BASE_URL}/upi-qr.jpeg", timeout=15)
    assert r.status_code == 200
    assert 'image' in r.headers.get('content-type', '').lower()
    assert int(r.headers.get('content-length', '0')) > 1000


# ------------------------- 2) Validation on POST -------------------------

def test_submit_requires_driver_auth():
    r = requests.post(f"{API}/driver/commission-payments",
                      json={'amount': 10, 'utr': 'ABCDEF'}, timeout=15)
    assert r.status_code in (401, 403)


def test_submit_rejects_amount_zero(driver_token):
    r = requests.post(f"{API}/driver/commission-payments",
                      json={'amount': 0, 'utr': 'ABCDEF'},
                      headers=_h(driver_token), timeout=15)
    assert r.status_code == 400


def test_submit_rejects_short_utr(driver_token):
    r = requests.post(f"{API}/driver/commission-payments",
                      json={'amount': 10, 'utr': 'abc'},
                      headers=_h(driver_token), timeout=15)
    assert r.status_code == 400


def test_submit_success_shape(driver_token):
    utr = f"UTR{uuid.uuid4().hex[:10].upper()}"
    r = requests.post(f"{API}/driver/commission-payments",
                      json={'amount': 25.5, 'utr': utr},
                      headers=_h(driver_token), timeout=15)
    assert r.status_code == 200, r.text
    d = r.json()
    for k in ('id', 'driver_id', 'driver_name', 'amount', 'utr', 'status',
              'submitted_at', 'applied_amount', 'applied_bookings'):
        assert k in d, f"missing {k}"
    assert d['status'] == 'pending'
    assert d['amount'] == 25.5
    assert d['utr'] == utr
    assert d['applied_amount'] == 0
    assert d['applied_bookings'] == []


# ------------------------- 3) Driver history -------------------------

def test_driver_history_returns_own_payments(driver_token):
    r = requests.get(f"{API}/driver/commission-payments",
                     headers=_h(driver_token), timeout=15)
    assert r.status_code == 200
    items = r.json()
    assert isinstance(items, list) and len(items) >= 1
    # sorted desc by submitted_at
    if len(items) > 1:
        assert items[0]['submitted_at'] >= items[1]['submitted_at']


# ------------------------- 4) Admin list + auth guards -------------------------

def test_admin_list_all(admin_token):
    r = requests.get(f"{API}/admin/commission-payments",
                     headers=_h(admin_token), timeout=15)
    assert r.status_code == 200
    assert isinstance(r.json(), list)


def test_admin_list_status_filter(admin_token):
    r = requests.get(f"{API}/admin/commission-payments?status=pending",
                     headers=_h(admin_token), timeout=15)
    assert r.status_code == 200
    for p in r.json():
        assert p['status'] == 'pending'


def test_admin_list_requires_admin(driver_token):
    r = requests.get(f"{API}/admin/commission-payments",
                     headers=_h(driver_token), timeout=15)
    assert r.status_code in (401, 403)


def test_review_requires_admin(driver_token):
    r = requests.patch(f"{API}/admin/commission-payments/does-not-matter",
                       json={'action': 'reject'},
                       headers=_h(driver_token), timeout=15)
    assert r.status_code in (401, 403)


# ------------------------- 5) Reject flow (no deduction + notification) -------------------------

def test_reject_flow(admin_token, driver_token, driver_id, approved_vehicle):
    _clear_owed(admin_token, driver_id)
    commissions = _seed_completed_trips(driver_token, approved_vehicle, n=2, distance_km=5)
    owed_before = round(sum(commissions), 2)

    utr = f"REJ{uuid.uuid4().hex[:10].upper()}"
    submit = requests.post(f"{API}/driver/commission-payments",
                           json={'amount': owed_before, 'utr': utr},
                           headers=_h(driver_token), timeout=15).json()

    rj = requests.patch(f"{API}/admin/commission-payments/{submit['id']}",
                        json={'action': 'reject', 'note': 'wrong utr'},
                        headers=_h(admin_token), timeout=15)
    assert rj.status_code == 200
    assert rj.json()['status'] == 'rejected'

    # commission owed unchanged
    c = requests.get(f"{API}/driver/commission", headers=_h(driver_token), timeout=15).json()
    assert round(c['commission_owed'], 2) >= owed_before - 0.01

    # in-app notification
    notif = requests.get(f"{API}/inapp/notifications", headers=_h(driver_token), timeout=15).json()
    titles = [i.get('title') for i in notif.get('items', [])]
    assert 'Commission payment rejected' in titles

    # cannot review twice
    r2 = requests.patch(f"{API}/admin/commission-payments/{submit['id']}",
                        json={'action': 'approve'},
                        headers=_h(admin_token), timeout=15)
    assert r2.status_code == 400
    assert 'already' in r2.text.lower()


# ------------------------- 6) Partial approve -------------------------

def test_partial_approve(admin_token, driver_token, driver_id, approved_vehicle):
    _clear_owed(admin_token, driver_id)
    commissions = _seed_completed_trips(driver_token, approved_vehicle, n=5, distance_km=5)
    owed = round(sum(commissions), 2)
    # Pay commission for exactly 2 oldest trips
    pay = round(commissions[0] + commissions[1], 2)

    utr = f"PART{uuid.uuid4().hex[:10].upper()}"
    submit = requests.post(f"{API}/driver/commission-payments",
                           json={'amount': pay, 'utr': utr},
                           headers=_h(driver_token), timeout=15).json()

    ap = requests.patch(f"{API}/admin/commission-payments/{submit['id']}",
                        json={'action': 'approve'},
                        headers=_h(admin_token), timeout=15)
    assert ap.status_code == 200, ap.text
    body = ap.json()
    assert body['status'] == 'approved'
    assert round(body['applied_amount'], 2) == pay
    assert len(body['applied_bookings']) == 2

    remaining = requests.get(f"{API}/driver/commission",
                             headers=_h(driver_token), timeout=15).json()
    assert round(remaining['commission_owed'], 2) == round(owed - pay, 2)

    notif = requests.get(f"{API}/inapp/notifications",
                         headers=_h(driver_token), timeout=15).json()
    titles = [i.get('title') for i in notif.get('items', [])]
    assert 'Commission payment approved' in titles


# ------------------------- 7) Full approve -------------------------

def test_full_approve(admin_token, driver_token, driver_id, approved_vehicle):
    _clear_owed(admin_token, driver_id)
    commissions = _seed_completed_trips(driver_token, approved_vehicle, n=3, distance_km=5)
    owed = round(sum(commissions), 2)

    utr = f"FULL{uuid.uuid4().hex[:10].upper()}"
    submit = requests.post(f"{API}/driver/commission-payments",
                           json={'amount': owed, 'utr': utr},
                           headers=_h(driver_token), timeout=15).json()
    ap = requests.patch(f"{API}/admin/commission-payments/{submit['id']}",
                        json={'action': 'approve'},
                        headers=_h(admin_token), timeout=15)
    assert ap.status_code == 200
    body = ap.json()
    assert round(body['applied_amount'], 2) == owed
    assert len(body['applied_bookings']) == 3
    c = requests.get(f"{API}/driver/commission", headers=_h(driver_token), timeout=15).json()
    assert round(c['commission_owed'], 2) == 0


# ------------------------- 8) Overpayment -------------------------

def test_overpayment_caps_applied_amount(admin_token, driver_token, driver_id, approved_vehicle):
    _clear_owed(admin_token, driver_id)
    commissions = _seed_completed_trips(driver_token, approved_vehicle, n=2, distance_km=5)
    owed = round(sum(commissions), 2)
    overpay = round(owed + 500, 2)

    utr = f"OVER{uuid.uuid4().hex[:10].upper()}"
    submit = requests.post(f"{API}/driver/commission-payments",
                           json={'amount': overpay, 'utr': utr},
                           headers=_h(driver_token), timeout=15).json()
    assert submit['amount'] == overpay

    ap = requests.patch(f"{API}/admin/commission-payments/{submit['id']}",
                        json={'action': 'approve'},
                        headers=_h(admin_token), timeout=15)
    assert ap.status_code == 200
    body = ap.json()
    assert round(body['applied_amount'], 2) == owed  # never exceeds owed
    c = requests.get(f"{API}/driver/commission", headers=_h(driver_token), timeout=15).json()
    assert round(c['commission_owed'], 2) == 0

    # Audit record still shows full amount
    hist = requests.get(f"{API}/driver/commission-payments",
                        headers=_h(driver_token), timeout=15).json()
    row = next(p for p in hist if p['id'] == submit['id'])
    assert row['amount'] == overpay
    assert round(row['applied_amount'], 2) == owed
