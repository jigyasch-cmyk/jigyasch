"""AvSGo iteration 4 tests: SEO homepage, sw.js, VAPID web push endpoints, cancel booking, full booking flow, existing endpoints unchanged."""
import os
import re
import base64
import io
import uuid
import pytest
import requests

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'https://book-ride-now-10.preview.emergentagent.com').rstrip('/')
API = f"{BASE_URL}/api"


# --------- Static / SEO ---------
class TestSEOAndStatic:
    def test_homepage_seo(self):
        r = requests.get(f"{BASE_URL}/", timeout=30)
        assert r.status_code == 200
        html = r.text
        assert '<title>AvSGo</title>' in html
        assert 'AvSGo is a local vehicle booking platform in Assam for E-rickshaw, Tata Ace, Tempo and Tractor goods transport services.' in html
        assert 'y7goxoWrbipq7CWXRN4Dd4IvKfzuvjcfBYxlO67UN5w' in html
        assert '"@type": "FAQPage"' in html or '"@type":"FAQPage"' in html
        # 8 questions
        qs = re.findall(r'"@type"\s*:\s*"Question"', html)
        assert len(qs) >= 8, f"Only {len(qs)} FAQ Question entries"

    def test_sw_js(self):
        r = requests.get(f"{BASE_URL}/sw.js", timeout=30)
        assert r.status_code == 200
        ct = r.headers.get('content-type', '')
        assert 'javascript' in ct.lower(), f"content-type is {ct}"
        assert 'push' in r.text.lower()

    def test_sitemap(self):
        r = requests.get(f"{BASE_URL}/sitemap.xml", timeout=30)
        assert r.status_code == 200
        assert 'xml' in r.headers.get('content-type', '').lower()

    def test_robots(self):
        r = requests.get(f"{BASE_URL}/robots.txt", timeout=30)
        assert r.status_code == 200
        assert 'text/plain' in r.headers.get('content-type', '').lower()


# --------- Push endpoints ---------
class TestPush:
    def test_public_key(self):
        r = requests.get(f"{API}/push/public-key", timeout=30)
        assert r.status_code == 200
        data = r.json()
        assert 'public_key' in data
        key = data['public_key']
        assert isinstance(key, str) and 80 <= len(key) <= 100, f"len={len(key)}"

    def test_subscribe_customer_no_auth(self):
        body = {
            'subscriber_key': 'customer:9111111111',
            'subscription': {'endpoint': 'https://example.com/e1', 'keys': {'p256dh': 'x', 'auth': 'y'}},
        }
        r = requests.post(f"{API}/push/subscribe", json=body, timeout=30)
        assert r.status_code == 200
        assert r.json() == {'ok': True}

    def test_subscribe_admin_requires_admin_token(self):
        body = {
            'subscriber_key': 'admin',
            'subscription': {'endpoint': 'https://example.com/admin1', 'keys': {'p256dh': 'x', 'auth': 'y'}},
        }
        # no auth => 403
        r = requests.post(f"{API}/push/subscribe", json=body, timeout=30)
        assert r.status_code == 403

        # admin login
        alr = requests.post(f"{API}/auth/admin/login", json={'mobile': '9365306642', 'password': 'Jigyasch@98'}, timeout=30)
        assert alr.status_code == 200
        atok = alr.json()['token']
        r2 = requests.post(f"{API}/push/subscribe", json=body, headers={'Authorization': f'Bearer {atok}'}, timeout=30)
        assert r2.status_code == 200

    def test_subscribe_driver_wrong_sub_forbidden(self):
        # Login driver
        dl = requests.post(f"{API}/auth/driver/login", json={'mobile': '9000000001', 'password': 'Driver@123'}, timeout=30)
        assert dl.status_code == 200
        dtok = dl.json()['token']
        body = {
            'subscriber_key': 'driver:some-other-id',
            'subscription': {'endpoint': 'https://example.com/d2', 'keys': {'p256dh': 'x', 'auth': 'y'}},
        }
        r = requests.post(f"{API}/push/subscribe", json=body, headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        assert r.status_code == 403

    def test_subscribe_driver_own_ok(self):
        dl = requests.post(f"{API}/auth/driver/login", json={'mobile': '9000000001', 'password': 'Driver@123'}, timeout=30)
        assert dl.status_code == 200
        data = dl.json()
        dtok = data['token']
        did = data['driver']['id']
        body = {
            'subscriber_key': f'driver:{did}',
            'subscription': {'endpoint': f'https://example.com/self-{uuid.uuid4()}', 'keys': {'p256dh': 'x', 'auth': 'y'}},
        }
        r = requests.post(f"{API}/push/subscribe", json=body, headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        assert r.status_code == 200


# --------- Full booking flow & cancel ---------
class TestBookingFlow:
    @pytest.fixture(scope='class')
    def ctx(self):
        # driver login
        dl = requests.post(f"{API}/auth/driver/login", json={'mobile': '9000000001', 'password': 'Driver@123'}, timeout=30)
        assert dl.status_code == 200
        dtok = dl.json()['token']

        # admin login
        al = requests.post(f"{API}/auth/admin/login", json={'mobile': '9365306642', 'password': 'Jigyasch@98'}, timeout=30)
        assert al.status_code == 200
        atok = al.json()['token']

        # Add vehicle - unique plate to avoid collision
        plate = f"AS02EE{uuid.uuid4().hex[:4].upper()}"
        add = requests.post(f"{API}/driver/vehicles",
                            json={'vehicle_type': 'E-Rickshaw', 'plate_no': plate, 'capacity': '200kg'},
                            headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        assert add.status_code == 200, add.text
        vid = add.json()['id']
        assert add.json()['status'] == 'pending'

        # Approve
        ap = requests.patch(f"{API}/admin/vehicles/{vid}", json={'action': 'approve'},
                            headers={'Authorization': f'Bearer {atok}'}, timeout=30)
        assert ap.status_code == 200 and ap.json()['status'] == 'approved'

        return {'dtok': dtok, 'atok': atok, 'vid': vid, 'plate': plate}

    def test_full_flow(self, ctx):
        # Create booking (no auth)
        body = {
            'vehicle_id': ctx['vid'],
            'customer_name': 'TEST_Cust',
            'customer_mobile': '9111100011',
            'pickup': 'A', 'drop_location': 'B',
            'distance_km': 5,
        }
        cr = requests.post(f"{API}/customer/bookings", json=body, timeout=30)
        assert cr.status_code == 200, cr.text
        bk = cr.json()
        bid = bk['id']
        assert bk['status'] == 'requested'
        assert bk['driver_mobile'] is None

        # Accept
        ac = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'accept'},
                            headers={'Authorization': f'Bearer {ctx["dtok"]}'}, timeout=30)
        assert ac.status_code == 200
        assert ac.json()['status'] == 'accepted'

        # customer sees driver mobile
        cs = requests.get(f"{API}/customer/bookings/{bid}", timeout=30)
        assert cs.status_code == 200 and cs.json()['driver_mobile'] == '9000000001'

        # complete
        cp = requests.patch(f"{API}/driver/bookings/{bid}", json={'action': 'complete'},
                            headers={'Authorization': f'Bearer {ctx["dtok"]}'}, timeout=30)
        assert cp.status_code == 200 and cp.json()['status'] == 'completed'

    def test_cancel_wrong_and_correct_mobile(self, ctx):
        # Create fresh booking
        body = {
            'vehicle_id': ctx['vid'], 'customer_name': 'TEST_Cancel', 'customer_mobile': '9222200022',
            'pickup': 'X', 'drop_location': 'Y', 'distance_km': 3,
        }
        cr = requests.post(f"{API}/customer/bookings", json=body, timeout=30)
        assert cr.status_code == 200
        bid = cr.json()['id']

        # wrong mobile
        w = requests.post(f"{API}/customer/bookings/{bid}/cancel", params={'mobile': '9999999999'}, timeout=30)
        assert w.status_code == 403

        # correct mobile
        ok = requests.post(f"{API}/customer/bookings/{bid}/cancel", params={'mobile': '9222200022'}, timeout=30)
        assert ok.status_code == 200 and ok.json()['status'] == 'cancelled'

        # confirm status
        g = requests.get(f"{API}/customer/bookings/{bid}", timeout=30)
        assert g.status_code == 200 and g.json()['status'] == 'cancelled'


# --------- Existing endpoints unchanged ---------
class TestExisting:
    def test_fare_settings(self):
        r = requests.get(f"{API}/fare-settings", timeout=30)
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list) and len(data) >= 4

    def test_admin_stats(self):
        al = requests.post(f"{API}/auth/admin/login", json={'mobile': '9365306642', 'password': 'Jigyasch@98'}, timeout=30)
        atok = al.json()['token']
        r = requests.get(f"{API}/admin/stats", headers={'Authorization': f'Bearer {atok}'}, timeout=30)
        assert r.status_code == 200
        d = r.json()
        for k in ('drivers', 'pending_vehicles', 'completed_trips', 'revenue', 'commission_earned', 'upi'):
            assert k in d
        assert d['upi'] == '9365306642@ptsbi'

    def test_driver_commission(self):
        dl = requests.post(f"{API}/auth/driver/login", json={'mobile': '9000000001', 'password': 'Driver@123'}, timeout=30)
        dtok = dl.json()['token']
        r = requests.get(f"{API}/driver/commission", headers={'Authorization': f'Bearer {dtok}'}, timeout=30)
        assert r.status_code == 200
        for k in ('commission_owed', 'total_earnings', 'trips', 'upi'):
            assert k in r.json()

    def test_upload_and_download(self):
        # 1x1 PNG
        png = base64.b64decode(
            'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII='
        )
        files = {'file': ('t.png', io.BytesIO(png), 'image/png')}
        r = requests.post(f"{API}/upload", files=files, timeout=60)
        assert r.status_code == 200, r.text
        fid = r.json()['id']
        d = requests.get(f"{API}/files/{fid}", timeout=30)
        assert d.status_code == 200 and len(d.content) > 0
