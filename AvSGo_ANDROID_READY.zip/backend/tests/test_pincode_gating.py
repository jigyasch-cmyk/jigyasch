"""Iter17: PIN-code gating + bbox-scoped geocode + regressions.

Covers:
  - /api/pincode/{pincode}  (784161 Bihpuria, 781001 Guwahati, 12345, abcdef, 999999)
  - /api/geocode with viewbox + bounded=1 (real Guwahati colleges)
  - /api/geocode without bbox (Assam-bias regression)
  - /api/geocode with bounded=1 & possibly-empty bbox (auto-expand tolerance)
  - Regression: /api/route, /api/reverse-geocode, POST /api/customer/bookings,
    /api/customer/bookings/auto, /api/public/vehicles, /api/fare-settings.
"""
import os
import time
import pytest
import requests

def _load_base():
    v = os.environ.get('REACT_APP_BACKEND_URL', '').strip()
    if not v:
        try:
            with open('/app/frontend/.env') as f:
                for line in f:
                    if line.startswith('REACT_APP_BACKEND_URL='):
                        v = line.split('=', 1)[1].strip()
                        break
        except Exception:
            pass
    return v.rstrip('/')

BASE_URL = _load_base()
assert BASE_URL, "REACT_APP_BACKEND_URL must be set"

# Guwahati-area sample bbox roughly around 781001
GUW_BBOX = {"west": 91.698, "south": 26.131, "east": 91.798, "north": 26.221}


@pytest.fixture(scope="module")
def s():
    sess = requests.Session()
    sess.headers.update({"Content-Type": "application/json"})
    return sess


# ---------- /api/pincode ----------
class TestPincode:
    def test_pincode_784161_bihpuria(self, s):
        r = s.get(f"{BASE_URL}/api/pincode/784161", timeout=20)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["pincode"] == "784161"
        assert isinstance(d.get("lat"), float) and isinstance(d.get("lng"), float)
        assert d["lat"] != 0 and d["lng"] != 0
        bb = d["bbox"]
        for k in ("south", "north", "west", "east"):
            assert isinstance(bb[k], float)
        assert bb["south"] < bb["north"] and bb["west"] < bb["east"]
        dn = (d.get("display_name") or "").lower()
        assert any(t in dn for t in ("bihpuria", "lakhimpur", "assam")), dn
        addr = d.get("address") or {}
        # state may live under 'state' key
        state = (addr.get("state") or "").lower()
        assert state == "assam" or "assam" in dn

    def test_pincode_781001_guwahati(self, s):
        r = s.get(f"{BASE_URL}/api/pincode/781001", timeout=20)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["pincode"] == "781001"
        bb = d["bbox"]
        assert bb["south"] < bb["north"] and bb["west"] < bb["east"]
        # Guwahati is around 26.14, 91.73
        assert 25.5 < d["lat"] < 26.7
        assert 91.3 < d["lng"] < 92.2
        dn = (d.get("display_name") or "").lower()
        assert "guwahati" in dn or "assam" in dn or "kamrup" in dn

    def test_pincode_5_digit_400(self, s):
        r = s.get(f"{BASE_URL}/api/pincode/12345", timeout=15)
        assert r.status_code == 400
        assert "valid 6-digit" in (r.json().get("detail") or "").lower()

    def test_pincode_alpha_400(self, s):
        r = s.get(f"{BASE_URL}/api/pincode/abcdef", timeout=15)
        assert r.status_code == 400

    def test_pincode_999999_not_found(self, s):
        r = s.get(f"{BASE_URL}/api/pincode/999999", timeout=25)
        assert r.status_code == 404, r.text
        assert "not found" in (r.json().get("detail") or "").lower()


# ---------- /api/geocode ----------
class TestGeocodeBbox:
    def test_geocode_college_in_guwahati_bbox(self, s):
        params = {"q": "college", "bounded": 1, **GUW_BBOX}
        r = s.get(f"{BASE_URL}/api/geocode", params=params, timeout=25)
        assert r.status_code == 200, r.text
        results = r.json().get("results", [])
        assert len(results) >= 1, f"Expected >=1 college in Guwahati bbox, got {results}"
        # At least one result should be inside (or very near) the bbox
        inside = 0
        for x in results:
            lat, lng = x["lat"], x["lng"]
            if GUW_BBOX["south"] - 0.05 <= lat <= GUW_BBOX["north"] + 0.05 and \
               GUW_BBOX["west"] - 0.05 <= lng <= GUW_BBOX["east"] + 0.05:
                inside += 1
        assert inside >= 1, f"No result inside/near bbox: {results}"
        # Assam locality mention
        joined = " ".join((x.get("display_name") or "") for x in results).lower()
        assert "guwahati" in joined or "assam" in joined or "kamrup" in joined

    def test_geocode_without_bbox_assam_bias(self, s):
        r = s.get(f"{BASE_URL}/api/geocode", params={"q": "Nalbari"}, timeout=25)
        assert r.status_code == 200
        results = r.json().get("results", [])
        assert len(results) >= 1
        assert "assam" in (results[0].get("display_name") or "").lower()

    def test_geocode_empty_bbox_no_crash(self, s):
        # deliberately obscure query in a tiny bbox – expect graceful empty (auto-expand may or may not find something)
        tiny = {"west": 91.7, "south": 26.14, "east": 91.702, "north": 26.142}
        params = {"q": "xyznonsense12345", "bounded": 1, **tiny}
        r = s.get(f"{BASE_URL}/api/geocode", params=params, timeout=25)
        assert r.status_code == 200
        assert "results" in r.json()
        assert isinstance(r.json()["results"], list)


# ---------- Regression ----------
class TestRegression:
    def test_public_vehicles(self, s):
        r = s.get(f"{BASE_URL}/api/public/vehicles", timeout=15)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_fare_settings(self, s):
        r = s.get(f"{BASE_URL}/api/fare-settings", timeout=15)
        assert r.status_code == 200
        d = r.json()
        assert isinstance(d, (dict, list))

    def test_reverse_geocode(self, s):
        r = s.get(f"{BASE_URL}/api/reverse-geocode",
                  params={"lat": 26.1445, "lng": 91.7362}, timeout=20)
        assert r.status_code == 200
        assert "display_name" in r.json()

    def test_route_guwahati_dispur(self, s):
        payload = {"pickup_lat": 26.1445, "pickup_lng": 91.7362,
                   "drop_lat": 26.1433, "drop_lng": 91.7898}
        r = s.post(f"{BASE_URL}/api/route", json=payload, timeout=25)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d.get("distance_km", 0) > 0
        assert "geometry" in d or "coords" in d or "coordinates" in d

    def test_create_booking_and_persist(self, s):
        # get any vehicle id
        vr = s.get(f"{BASE_URL}/api/public/vehicles", timeout=15).json()
        if not vr:
            pytest.skip("No vehicles available to book")
        vid = vr[0].get("id") or vr[0].get("_id")
        payload = {
            "vehicle_id": vid,
            "customer_name": "TEST_Iter17",
            "customer_mobile": "9876500177",
            "pickup": "Guwahati",
            "drop_location": "Dispur",
            "distance_km": 6.5,
            "pickup_lat": 26.1445, "pickup_lng": 91.7362,
        }
        r = s.post(f"{BASE_URL}/api/customer/bookings", json=payload, timeout=20)
        assert r.status_code in (200, 201), r.text

    def test_bookings_auto(self, s):
        r = s.get(f"{BASE_URL}/api/customer/bookings/auto",
                  params={"mobile": "9876500177"}, timeout=15)
        # endpoint might require different param; accept 200/400/404 but not 500
        assert r.status_code < 500, r.text
